//1부터 100까지의 데이터에서 짝수의 합과 홀수의 합을 각각 계산하여 출력

package package11;

public class MyThreadTest6 {
    private int start;
    private int end;

    // 생성자를 통해 시작 값과 끝 값을 설정
    public MyThreadTest6(int start, int end) {
        this.start = start;
        this.end = end;
    }

    // 짝수의 합을 계산하는 메소드
    void evenSum() {
        int sum = 0;
        for (int i = start; i <= end; i++) {
            if (i % 2 == 0) {
                sum += i;
            }
        }
        System.out.println(sum);
    }

    // 홀수의 합을 계산하는 메소드
    void oddSum() {
        int sum = 0;
        for (int i = start; i <= end; i++) {
            if (i % 2 != 0) {
                sum += i;
            }
        }
        System.out.println(sum);
    }

    public static void main(String[] args) {
    	MyThreadTest6 even = new MyThreadTest6(1,100);
    	MyThreadTest6 odd = new MyThreadTest6(1,100);
       
       
       even.evenSum();
       odd.oddSum();
    }
   }