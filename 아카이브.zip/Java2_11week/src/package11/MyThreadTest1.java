//11/13 
package package11;


class MyThread extends Thread{
		public void run() {
				System.out.println("내가 호출될 거야....");
		}
}
public class MyThreadTest1 {
		public static void main(String[] args) {
			Thread t =  new MyThread();
			
			t.start();
		}
}
