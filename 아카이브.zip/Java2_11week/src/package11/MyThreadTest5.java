package package11;

class NumberThread extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Number: " + i);

            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class LetterThread extends Thread {
    public void run() {
        for (char ch = 'A'; ch <= 'E'; ch++) {
            System.out.println("Letter: " + ch);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

public class MyThreadTest5 {

    public static void main(String[] args) {
        Thread nt = new Thread(new MyThread4("NumberThread"));
        Thread lt = new LetterThread();

        nt.start();
        lt.start();

        try {
            nt.join();
            lt.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("프로그램을 종료합니다.");
    }
}
