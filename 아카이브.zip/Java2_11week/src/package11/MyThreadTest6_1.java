package package11;

class EvenSum implements Runnable {
    private int start;
    private int end;

    // 생성자를 통해 시작 값과 끝 값을 설정
    public EvenSum(int start, int end) {
        this.start = start;
        this.end = end;
    }

    // 짝수의 합을 계산하여 출력하는 메서드
    public void run() {
        int sum = 0;
        for (int i = start; i <= end; i++) {
            if (i % 2 == 0) {
                sum += i;
            }
        }
        System.out.println("짝수의 합: " + sum);
    }
}

class OddSum implements Runnable {
    private int start;
    private int end;

    // 생성자를 통해 시작 값과 끝 값을 설정
    public OddSum(int start, int end) {
        this.start = start;
        this.end = end;
    }

    // 홀수의 합을 계산하여 출력하는 메서드
    public void run() {
        int sum = 0;
        for (int i = start; i <= end; i++) {
            if (i % 2 != 0) {
                sum += i;
            }
        }
        System.out.println("홀수의 합: " + sum);
    }
}

public class MyThreadTest6_1 {
    public static void main(String[] args) {
        int st = 1;
        int end = 100;

        // 스레드 객체 생성 및 초기화
        Thread evenSumThread = new Thread(new EvenSum(st, end));
        Thread oddSumThread = new Thread(new OddSum(st, end));
        
        // 스레드 실행
        evenSumThread.start();
        oddSumThread.start();

        try {
            // 두 스레드가 종료될 때까지 대기
            evenSumThread.join();
            oddSumThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            System.out.println("프로그램을 종료합니다.");
        }
    }
}
