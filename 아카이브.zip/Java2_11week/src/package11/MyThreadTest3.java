package package11;

class MyThread3 implements Runnable{
	public void run() {
		for (int i = 1; i <= 10; i++) {
			System.out.print(i + "...");
		}
	}
}

public class MyThreadTest3 {

	public static void main(String[] args) {
		Thread t = new Thread(new MyThread3());
		
		t.start();
		System.out.println("난 main()에서 출력된거야~");
	}

}
