package week12_data;
//12주차 후위표기법 계산 page13
import java.util.Stack;

public class RPNCalculator {

    // 후위 표기법 수식을 계산하는 메서드
    public static int evaluateRPN(String[] tokens) {
        Stack<Integer> stack = new Stack<>();

        for (String token : tokens) {
            if (isOperator(token)) {
                int b = stack.pop(); // 스택에서 피연산자 꺼내기
                int a = stack.pop(); // 스택에서 피연산자 꺼내기
                int result = applyOperator(a, b, token); // 연산 수행
                stack.push(result); // 결과를 스택에 다시 넣기
            } else {
                stack.push(Integer.parseInt(token)); // 피연산자를 스택에 넣기
            }
        }

        return stack.pop(); // 최종 결과 반환
    }

    // 주어진 문자열이 연산자인지 확인하는 메서드
    private static boolean isOperator(String token) {
        return "+-*/^".contains(token);
    }

    // 연산자를 적용하여 두 피연산자를 계산하는 메서드
    private static int applyOperator(int a, int b, String operator) {
        switch (operator) {
            case "+":
                return a + b;
            case "-":
                return a - b;
            case "*":
                return a * b;
            case "/":
                return a / b;
            case "^":
                return (int) Math.pow(a, b);
            default:
                throw new IllegalArgumentException("잘못된 연산자: " + operator); // 아닌 경우에는 이것 출력 
        }
    }

    public static void main(String[] args) {
        // 여러 예제 후위 표기법 수식
        String[][] expressions = {
            {"4", "18", "6", "3", "-", "/", "+"},
            {"3", "4", "+", "5", "2", "-", "*"},
            {"5", "1", "2", "+", "4", "*", "+", "3", "-"},
            {"2", "3", "1", "*", "+", "9", "5", "/", "-", "8", "2", "^", "+"}
        };

        // 각 수식을 계산하고 결과를 출력
        for (String[] expression : expressions) {
            System.out.println(evaluateRPN(expression));
        }
    }
}
