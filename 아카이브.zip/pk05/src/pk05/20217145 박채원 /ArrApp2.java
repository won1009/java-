package pk05;

public class ArrApp2 {
    
    public void calPrint(ArrObject obj) {
        for (int data : obj.arr) {
            System.out.print(data + " ");
        }
        System.out.println("\n--------------------------");
    }

    public ArrObject cal(ArrObject obj) {
        for (int i = 0; i < obj.arr.length; i++) {
            obj.arr[i] *= 2;  
        }
        return obj; 
    }

    public static void main(String[] args) {
        ArrApp2 k = new ArrApp2(); 
        
        ArrObject ar = new ArrObject(new int[] {2,4,6});
        
        k.calPrint(ar);
        ar = k.cal(ar);
        k.calPrint(ar);
    }
}


