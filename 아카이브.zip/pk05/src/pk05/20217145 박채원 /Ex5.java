//ex5
package pk05;

abstract class Ex5Abstract{
    String name; int a, b;
    
    abstract void eSum();
    abstract void eAvg();
    abstract void eGrade();
}

public class Ex5 extends Ex5Abstract { // 추상클래스&추상메소드(추상클래스가 적용된 객체지향 프로그래밍 구조
    char res; double sum, avg; 
    
    void eInput() {
       sum = 0.0; avg = 0.0;
       
       name = "홍길동";
       a = 100; b= 97;
    }
    
    public void eSum() {
       sum = a + b;
    }
    
    public void eAvg() {
       avg = (double)sum/2; // (a+b)/2.0
    }
    
    public void eGrade() {
       if (avg>=90)
          res = 'A';
       else if (avg >= 80 && avg <90)
          res = 'B';
       else if (avg >=70 && avg <80)
          res = 'C';
       else if (avg >= 60 && avg <70)
          res = 'D';
       else
          res = 'F';
    }
    
    void ePrint() {
       System.out.printf("입력된 이름과 두 개의 점수는 %s, %d, %d이고, \n", name, a, b);
       System.out.printf("합은 %.2f, 평균은 %.2f, 학점은 %c 입니다.", sum, avg, res);
    }
    
   public static void main(String[] args) {
      Ex5 k = new Ex5();
      
      k.eInput();
      k.eSum();
      k.eAvg();
      k.eGrade();
      k.ePrint();
      }
}
