//10.02 5주차 
package pk05;
public class Ex1 {
    public static void main(String[] args) {
       
        String name = "홍길동";
        int score1 = 100;
        int score2 = 97;
        double sum; // sum을 double로 정의
        double avg;
        char grade;
        
        sum = score1 + score2; // sum은 double로 계산
        avg = sum / 2.0; // 평균은 double 형으로 계산

        // 학점 계산
        if (avg >= 90 && avg <= 100) {  grade = 'A';
        } else if (avg >= 80 && avg < 90) {    grade = 'B';
        } else if (avg >= 70 && avg < 80) {    grade = 'C';
        } else if (avg >= 60 && avg < 70) {    grade = 'D';
        } else { grade = 'F';
        }
        System.out.printf("출력결과");         // 결과 출력
        System.out.printf("입력된 이름과 두 개의 점수는 %s, %d, %d 이고,\n", name, score1, score2);
        System.out.printf("합은 %.2f, 평균은 %.2f, 학점은 %c 입니다.\n", sum, avg, grade);
    }
}
