package pk05;

public class ArrObject {
    int[] arr;

    // 기본 생성자: 기본 값으로 초기화
    public ArrObject() {
        arr = new int[] {10, 20, 30, 40, 50};
    }

    // 배열을 사용자 정의 배열로 초기화하는 생성자
    public ArrObject(int[] arr) {
        this.arr = arr;
    }

    // 배열 요소를 출력하는 메서드
    public void print() {
    System.out.print("배열 요소: ");
        for (int data : arr) {
            System.out.print(data + " ");
        }
        System.out.println("\n--------------------------");
    }
}
