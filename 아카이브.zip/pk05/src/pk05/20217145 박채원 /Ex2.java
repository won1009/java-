package pk05;

public class Ex2 {
    String name;
    int score1,score2;
    double sum;
    double avg;
    char grade;

    void eInput() {
        name = "홍길동";
        score1 = 100;
        score2 = 97;
    }

    void eSum() {
        sum = score1 + score2;
    }

    void eAvg() {
        avg = sum / 2.0;
    }

    void eGrade() {
        if (avg >= 90 && avg <= 100) {
            grade = 'A';
        } else if (avg >= 80 && avg < 90) {
            grade = 'B';
        } else if (avg >= 70 && avg < 80) {
            grade = 'C';
        } else if (avg >= 60 && avg < 70) {
            grade = 'D';
        } else {
            grade = 'F';
        }
    }

    void ePrint() {
        System.out.printf("출력결과\n");
        System.out.printf("입력된 이름과 두 개의 점수는 %s, %d, %d 이고,\n", name, score1, score2);
        System.out.printf("합은 %.2f, 평균은 %.2f, 학점은 %c 입니다.\n", sum, avg, grade);
    }

    public static void main(String[] args) {
        Ex2 k = new Ex2();
        k.eInput();
        k.eSum();
        k.eAvg();
        k.eGrade();
        k.ePrint();
    }
}
