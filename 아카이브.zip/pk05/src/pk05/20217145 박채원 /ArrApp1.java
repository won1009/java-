package pk05;

public class ArrApp1 {
    public static void main(String[] args) {
        // 기본 값으로 인스턴스 생성
        ArrObject k = new ArrObject();
        k.print();
        
        // 사용자 정의 배열로 새로운 인스턴스 생성
        k = new ArrObject(new int[]{100, 200, 300});
        k.print();
        
        // 배열을 사용하여 인스턴스를 생성하고 출력
        new ArrObject(new int[]{1, 2, 3}).print();
    }
}
