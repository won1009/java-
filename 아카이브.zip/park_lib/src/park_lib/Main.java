package park_lib;

//열거형 정의
enum ProgrammingLanguage {
 JAVA("객체 지향적이고 안정적인 언어"),
 PYTHON("간결하고 읽기 쉬운 언어"),
 C("시스템 프로그래밍에 적합한 언어"),
 JAVASCRIPT("웹 개발에 널리 사용되는 언어"),
 RUBY("신속한 개발과 유연한 문법을 갖는 언어");

 // 각 프로그래밍 언어의 특징을 나타내는 멤버 변수
 private String description;

 // 생성자
 ProgrammingLanguage(String description) {
     this.description = description;
 }

 // 특징을 반환하는 메서드
 public String getDescription() {
     return description;
 }
}

public class Main {
 public static void main(String[] args) {
     // 열거형 상수 사용
     ProgrammingLanguage language = ProgrammingLanguage.JAVA;
     
     // 열거형 상수에 따른 특징 출력
     switch (language) {
         case JAVA:
             System.out.println("Java는 " + language.getDescription());
             break;
         case PYTHON:
             System.out.println("Python은 " + language.getDescription());
             break;
         case C:
             System.out.println("C는 " + language.getDescription());
             break;
         case JAVASCRIPT:
             System.out.println("JavaScript는 " + language.getDescription());
             break;
         case RUBY:
             System.out.println("Ruby는 " + language.getDescription());
             break;
         default:
             System.out.println("알 수 없는 언어입니다.");
     }
 }
}

/*
// 열거형 정의
enum Weekday {
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
}

public class Main {
    public static void main(String[] args) {
        // 열거형 상수 사용
        Weekday today = Weekday.WEDNESDAY;
        System.out.println("Today is " + today);
        
        // 열거형 상수 비교
        if (today == Weekday.WEDNESDAY) {
            System.out.println("It's Wednesday!");
        } else {
            System.out.println("It's not Wednesday.");
        }
        
        // 열거형 상수 순회
        System.out.println("All weekdays:");
        for (Weekday day : Weekday.values()) {
            System.out.println(day);
        }
    }
}
*/