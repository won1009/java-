package pack1;

public class pack1 {
	public void method() {
		System.out.println("A 메소드 실행");
	}
}
