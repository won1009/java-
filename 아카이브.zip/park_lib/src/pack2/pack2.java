package pack2;

public class pack2 {


	public void method() {
		System.out.println("A 메소드 실행");
	}
}
