
enum Weekday {
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
}
/ 메인 메서드
public static void main(String[] args) {
    Weekday today = Weekday.WEDNESDAY;
    printWeekday(today);
}
}

