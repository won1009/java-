package week12_java2;

interface Interface<T> {
    public void setSize(int c);
    public void set(T a);
    public T get(int i);
}

class Data<T> implements Interface<T> {
    private Object[] dataList;
    private int cnt = 0;

    // 리스트의 크기를 설정하는 메서드
    public void setSize(int c) {
        dataList = new Object[c];
    }

    // 리스트의 특정 위치에 값을 설정하는 메서드
    public void set(T a) {
        dataList[cnt++] = a;
    }

    // 데이터를 출력하는 메서드
    public void print() {
        for (Object value : dataList) {
            System.out.print(value + " ");
        }
        System.out.println();
    }

    // 특정 위치의 값을 반환하는 메서드
    public T get(int i) {
        return (T)dataList[i];
    }
}

public class Ex04 {
    public static void main(String[] args) {
        // Integer 타입을 사용하는 Data 객체 생성 및 사용
        Data<Integer> k2 = new Data<>();
        k2.setSize(5);

        for (int i = 0; i < 5; i++) {
            k2.set((i + 1) * 10); // 10, 20, 30, 40, 50 설정
        }
        k2.print(); // 10 20 30 40 50 출력
        
        System.out.println("\n---------------------");

        // String 타입을 사용하는 Data 객체 생성 및 사용
        Data<String> k2S = new Data<>();
        k2S.setSize(3);

        k2S.set("홍길동");
        k2S.set("박달문");
        k2S.set("이순길");

        k2S.print(); // 홍길동 박달문 이순길 출력
    }
}
