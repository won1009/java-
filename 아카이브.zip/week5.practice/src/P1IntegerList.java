package practice1;

public class P1IntegerList implements IntegerListInterface {
    private Integer[] item; // 원소들이 저장되는 배열
    private int numItems; // 원소의 갯수
    private static final int DEFAULT_CAPACITY = 64; // 기본 크기

    /**
     * 기본 생성자. 
     * 내부 배열을 기본 크기로 초기화하고, 원소 개수를 0으로 설정.
     */
    public IntegerList() {
        // 여기에 코드 작성
    }

    
    /**
     * 정수 n을 인자로 받는 생성자.
     * 내부 배열을 n의 크기로 초기화하고, 원소 개수를 0으로 설정.
     * 
     * @param n 내부 배열의 초기 크기
     */
    public IntegerList(int n) {
        // 여기에 코드 작성
    }

    
    /**
     * 리스트의 i번째 원소를 반환
     * 
     * @param i 원소의 인덱스
     * @return i번째 원소
     */
    @Override
    public Integer get(int i) {
	// 여기에 코드 작성
    }

    
    /**
     * 리스트의 i번째 원소를 x로 설정
     * 
     * @param i 설정할 위치의 인덱스
     * @param x 설정할 원소
     */
    @Override
    public void set(int i, Integer x) {
	// 여기에 코드 작성
    }

    
    /**
     * 리스트의 i번째 위치에 원소 x를 삽입 삽입 후 true를 반환
     * 
     * @param i 삽입할 위치의 인덱스
     * @param x 삽입할 원소
     * @return 삽입 성공 여부
     */
    @Override
    public boolean add(int i, Integer x) {
	// 여기에 코드 작성
    }

    
    /**
     * 리스트의 맨 끝에 원소 x를 추가
     * 
     * @param x 추가할 원소
     */
    @Override
    public void append(Integer x) {
	// 여기에 코드 작성
    }

    
    /**
     * 원소 x가 리스트의 몇 번째 원소인지 반환
     * 
     * @param x 검색할 원소
     * @return 원소의 인덱스, 존재하지 않을 경우 -1 반환
     */
    @Override
    public int indexOf(Integer x) {
	// 여기에 코드 작성
    }

    
    /**
     * 리스트가 비어 있는지 여부를 반환
     * 
     * @return 리스트가 비어있으면 true, 그렇지 않으면 false
     */
    @Override
    public boolean isEmpty() {
	// 여기에 코드 작성
    }

    
    /**
     * 리스트의 i번째 원소를 삭제
     * 
     * @param i 삭제할 위치의 인덱스
     * @return 삭제 성공 여부
     */
    @Override
    public boolean remove(int i) {
	// 여기에 코드 작성
    }

    
    /**
     * 리스트에서 원소 x를 찾아 삭제
     * 
     * @param x 삭제할 원소
     * @return 삭제 성공 여부
     */
    @Override
    public boolean removeItem(Integer x) {
	// 여기에 코드 작성
    }

    
    /**
     * 리스트의 원소 개수를 반환
     * 
     * @return 리스트의 원소 개수
     */
    @Override
    public int len() {
	// 여기에 코드 작성
    }

    
    /**
     * 리스트의 모든 원소를 삭제
     */
    @Override
    public void clear() {
	// 여기에 코드 작성
    }
}
