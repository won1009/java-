package practice1;

/**
 * P1IntegerList 클래스를 상속 받아 리스트 출력, 크기 동적 확장 및 축소 기능이 포함된
 * E1FlexibleIntegerList 클래스를 구현
 */
public class E1FlexibleIntegerList extends P1IntegerList{
   
    /**
     * 기본 생성자. 상위 클래스의 생성자를 호출하여 초기화를 수행
     */
    public E1FlexibleIntegerListFull() {
        // 여기에 코드 작성
    }
    
    /**
     * 기본 생성자. 상위 클래스의 생성자를 호출하여 초기화를 수행
     * @param n 배열의 초기 크기
     */
    public E1FlexibleIntegerListFull(int n) {
        // 여기에 코드 작성
    }
    
    /**
     * 리스트의 모든 원소를 "(원소1, 원소2, ...)" 형식으로 출력
     */
    public void printList() {
        // 여기에 코드 작성
    }
    
    /**
     * 리스트의 내부 배열 크기를 필요에 따라 확장
     * 만약 리스트의 현재 원소 개수가 내부 배열의 크기와 같아 더 이상 새로운 원소를 추가할 공간이 없을 때,
     * 내부 배열의 크기를 현재의 두 배로 증가
     * 확장된 배열에는 기존의 모든 원소가 유지
     */
    public void expandList() {
        // 여기에 코드 작성
    }
    
    /**
     * 리스트의 내부 배열 크기를 필요에 따라 축소
     * 만약 리스트의 현재 원소 개수가 내부 배열의 크기의 절반보다 적을 때,
     * 내부 배열의 크기를 현재 원소의 수에 맞게 조정
     * 축소된 배열에는 기존의 모든 원소가 유지
     * 단, 원소의 개수가 내부 배열의 크기의 절반 이상인 경우에는 배열의 크기를 조정하지 않음
     */
    public void shrinkList() {
        // 여기에 코드 작성
    }
    
    /**
     * 원소를 리스트에 추가하며, 필요 시 내부 배열을 확장.
     * @param i 삽입할 위치의 인덱스
     * @param x 삽입할 원소
     * @return 원소 삽입 성공 여부
     */
    @Override
    public boolean add(int i, Integer x) {
        // 여기에 코드 작성
    }
    
    /**
     * 원소를 리스트의 끝에 추가하며, 필요 시 내부 배열을 확장.
     * @param x 추가할 원소
     */
    @Override
    public void append(Integer x) {
        // 여기에 코드 작성
    }
    
    /**
     * 원소를 리스트에서 제거하며, 필요 시 내부 배열을 축소.
     * @param i 제거할 위치의 인덱스
     * @return 원소 제거 성공 여부
     */
    @Override
    public boolean remove(int i) {
        // 여기에 코드 작성
    }
    
    /**
     * 지정된 원소를 찾아 리스트에서 제거하며, 필요 시 내부 배열을 축소.
     * @param x 제거할 원소
     * @return 원소 제거 성공 여부
     */
    @Override
    public boolean removeItem(Integer x) {
        // 여기에 코드 작성
    }
}
