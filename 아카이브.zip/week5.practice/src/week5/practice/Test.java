package week5.practice;

public class Test {
    public static void main(String[] args) {
       // P1IntegerList list = new P1IntegerList(); // 크기가 2인 P1IntegerList 객체 생성
    	E1FlexibleIntegerList list = new E1FlexibleIntegerList(2);
        /* TEST */
        list.add(0, 300);
        list.add(0, 200);
        list.add(0, 100);
    //    System.out.println(list.indexOf(200));
    //    System.out.println("(" + list.get(0) + " " + list.get(1) + " " + list.get(2) + ")");
        // list.printList();

        list.append(500);
        list.append(600);
        list.remove(2);
        list.printList();  

//        list.add(3, 250);
//        list.add(1, 50);
//        list.add(0, 10);
//        list.append(700);
//        list.remove(1);
//        list.remove(5);
//        list.removeItem(300);
//        list.removeItem(200);
//        System.out.println("(" + list.get(0) + " " + list.get(1) + " " + list.get(2) + " " + list.get(3) +  " " + list.get(4) +  " " + list.get(5) + ")");
//        list.printList();

//        list.clear();
//        list.printList();

        /* TEST */
//        list.add(0, 1);
//        list.add(1, 10);   
//        list.add(3, 1000); // 잘못된 입력
//        list.add(2, 5);
//        list.add(1, 2); 
//        
//        // [1 2 10 5]
//        System.out.println(list.get(0));
//        System.out.println(list.get(1));
//        System.out.println(list.get(2));
//        System.out.println(list.get(3));
//        
//        list.append(50); // [1 2 10 5 50]
//        System.out.println(list.get(4));
//
//        System.out.println("==========");
//        list.remove(2); // [1 2 5 50]
//        System.out.println(list.get(0));
//        System.out.println(list.get(1));
//        System.out.println(list.get(2));
//        System.out.println(list.get(3));
//        
//        System.out.println("==========");
//        list.removeItem(2);
//        list.set(0, 1000);
//        System.out.println(list.get(0));
//        System.out.println(list.get(1));
//        System.out.println(list.get(2));
//        System.out.println(list.get(3));
//        
//        System.out.println("==========");
//        list.clear();
//        System.out.println(list.isEmpty());
//        System.out.println(list.get(0));
    }
}
