package week5.practice;
//0403 수요일 실습 코드 
public class P1IntegerList implements IntegerListInterface {
	protected Integer[] item; // 'private'를 'protected'로 변경 test 코드 돌릴 땐 다시 private 로 변경 
 // 원소들이 저장되는 배열
    private int numItems; // 원소의 갯수
    private static final int DEFAULT_CAPACITY = 64; // 기본 크기

    /**
     * 기본 생성자. 
     * 내부 배열을 기본 크기로 초기화하고, 원소 개수를 0으로 설정.
     */
    public P1IntegerList() {
        item = new Integer[DEFAULT_CAPACITY];
        numItems = 0;
    }

    
    /**
     * 정수 n을 인자로 받는 생성자.
     * 내부 배열을 n의 크기로 초기화하고, 원소 개수를 0으로 설정.
     * 
     * @param n 내부 배열의 초기 크기
     */
    public P1IntegerList(int n) {
        item = new Integer[n];
        numItems = 0;
    }

    
    /**
     * 리스트의 i번째 원소를 반환
     * 
     * @param i 원소의 인덱스
     * @return i번째 원소
     * @throws IndexOutOfBoundsException 주어진 인덱스가 올바르지 않은 경우
     */
    @Override
    public Integer get(int i) {
        if (i < 0 || i >= numItems) {
         System.out.println("(get)잘못된 입력입니다");
        }
        return item[i];
    }

    /**
     * 리스트의 i번째 원소를 x로 설정
     * 
     * @param i 설정할 위치의 인덱스
     * @param x 설정할 원소
     * @throws IndexOutOfBoundsException 주어진 인덱스가 올바르지 않은 경우
     */
    @Override
    public void set(int i, Integer x) {
        if (i < 0 || i >= numItems) {
        	 System.out.println("(set)잘못된 입력입니다");
        }
        item[i] = x;
    }

    /**
     * 리스트의 i번째 위치에 원소 x를 삽입 삽입 후 true를 반환
     * 
     * @param i 삽입할 위치의 인덱스
     * @param x 삽입할 원소
     * @return 삽입 성공 여부
     */
    @Override
    public boolean add(int i, Integer x) {
        if (i > numItems || i < 0) {
            System.out.println("(Add) 잘못된 입력입니다");
            return false;
        } else if (numItems == item.length) {
            System.out.println("(Add) 오버플로우가 발생합니다");
            return false;
        }
        
        numItems++;
        
        /* 1 번 이렇게 써도 되고 
        for (int j = numItems - 2; j >= i; j--) {
            item[j] = item[j - 1]; 
        }
        item[i] = x; // 지정된 위치에 새 원소 추가
        return true;
        */
        
        System.arraycopy(item, i, item, i + 1, numItems -1);//2번으로 이렇게 작성도 가능
       item[i] = x;
       return false;
    }


    
    /**
     * 리스트의 맨 끝에 원소 x를 추가
     * 
     * @param x 추가할 원소
     */
    @Override
    public void append(Integer x) {
        if (numItems == item.length) {
            System.out.println("(append) 오버플로우가 발생합니다");
            return;
        }
       
        numItems++;
        item[numItems - 1] = x;
    }

 
    /**
     * 원소 x가 리스트의 몇 번째 원소인지 반환
     * 
     * @param x 검색할 원소
     * @return 원소의 인덱스, 존재하지 않을 경우 -1 반환
     */
    @Override
    public int indexOf(Integer x) {
        for (int i = 0; i < numItems - 1; i++) {
            if (item[i] == (x)) {
                return i;
            }
        }
        return -1;
    }

    
    /**
     * 리스트가 비어 있는지 여부를 반환
     * 
     * @return 리스트가 비어있으면 true, 그렇지 않으면 false
     */
    @Override
    public boolean isEmpty() {
        return numItems == 0;
    }

    
    /**
     * 리스트의 i번째 원소를 삭제
     * 
     * @param i 삭제할 위치의 인덱스
     * @return 삭제 성공 여부
     */
    @Override
    public boolean remove(int i) {
        if (i < 0 || i >= numItems || isEmpty()) {
            System.out.println("(remove) 잘못된 입력입니다");
            return false;
        }

        numItems--;
        System.arraycopy(item, i + 1, item, i, numItems - i);
        return true;
    }

   
   /**
 * 리스트에서 원소 x를 찾아 삭제
 * 
 * @param x 삭제할 원소
 * @return 삭제 성공 여부
 */
@Override
public boolean removeItem(Integer x) {
    int k = indexOf(x);
    if (k == -1) {
        return false;
    } else {
        remove(k);
        return true;
    }
}


    
    /**
     * 리스트의 원소 개수를 반환
     * 
     * @return 리스트의 원소 개수
     */
    @Override
    public int len() {
        return numItems;
    }

    
    /**
     * 리스트의 모든 원소를 삭제
     */
    @Override
    public void clear() {
    	item = new integer[item.length];
        numItems = 0;
    }
}
