package Java2_7week;

public class Ex2 {
    int x;
    int y;            
    
    public Ex2() {
        x = 10;
        y = 20; 
    }
   void eswap() {
        int tmp;
        tmp = x;
        x = y;
        y = tmp;
    }
     void eprint() {
        System.out.println("x = " + x + ", y = " + y);
    }
    public static void main(String[] args) {     
        Ex2 k = new Ex2(); 
        k.eprint();       
        k.eswap();      
        k.eprint();     
    }
}
