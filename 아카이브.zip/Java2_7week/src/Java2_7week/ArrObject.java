package Java2_7week;

public class ArrObject {
	int[] arr;
	
	public ArrObject() {
		arr = new int[] {10,20,30,40,50};
	}
	ArrObject(int[]arr){
		this.arr= arr;
	}
	void print() {
		for(int i = 0 ; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println(" ");
	}
}


