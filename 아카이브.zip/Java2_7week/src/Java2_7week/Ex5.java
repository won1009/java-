package Java2_7week;


abstract class Ex5Abs{
	int[] arr;
	abstract void sort();
}

public class Ex5 extends Ex5Abs{

	@Override
	public void sort() {
		arr = new int[] {100, 1, 27, 88, 15, 45, 37};
		for (int i = 0; i < arr.length-1; i++) {
			for (int k = i + 1; k < arr.length; k++) {
				if (arr[i] > arr[k]) {
					int tmp;
					tmp = arr[i];
					arr[i] = arr[k];
					arr[k] = tmp;
				}
			}
		}	
		
		for (int d : arr) 
			System.out.print(d + " ");
		
	}
	
	
	public static void main(String[] args) {
		Ex5 ex = new Ex5();
		ex.sort();
	}
}
