package Java2_7week;

public class Ex1 {

	public static void main(String[] args) {
		ArrObject k = new ArrObject();
		
		k.print();
		
		k = new ArrObject(new int[] {100, 200, 300});
		
		k.print();
		
		new ArrObject(new int[] {1, 2, 3}).print();
	}

}
