package pk06;
import java.util.Random;
import java.util.Scanner;

interface Ex4Set{
	int Random();
	void bingo();
	
}

class Ex4Class implements Ex4Set{
	int rand; 
	
	@Override
	public int Random() {
		Random random = new Random();
		random.setSeed(System.currentTimeMillis());
		rand = random.nextInt(11);
		return rand;
	}
	
	@Override
	public void bingo() {
		int num;
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.print("숫자를 입력하세요 : ");
			num = sc.nextInt();
			
			if (num == rand) {
				System.out.println("-----------> 정답입니다. 축하합니다.");
				break;
			}
			else if (num > rand) {
				System.out.println("-----------> 숫자가 정답보다 높습니다.");
			}
			else if (num < rand) {
				System.out.println("-----------> 숫자가 정답보다 낮습니다.");
			}
		}
	}
}
public class Ex4 extends Ex4Class{

	public static void main(String[] args) {
		Ex4 ex = new Ex4();
		
		ex.Random();
		ex.bingo();

	}

}
