package pk06;
import java.util.Random;
import java.util.Scanner;


public class Ex1 {

	public static void main(String[] args) {
		int rand; 
		int num;
		Scanner sc = new Scanner(System.in);
		Random random = new Random();
		random.setSeed(System.currentTimeMillis());
		
		rand = random.nextInt(11);
		
		while(true) {
			System.out.print("숫자를 입력하세요 : ");
			num = sc.nextInt();
			
			if (num == rand) {
				System.out.println("-----------> 정답입니다. 축하합니다.");
				break;
			}
			else if (num > rand) {
				System.out.println("-----------> 숫자가 정답보다 높습니다.");
			}
			else if (num < rand) {
				System.out.println("-----------> 숫자가 정답보다 낮습니다.");
			}
		}
		
	}

}
