package pk06;
import java.util.Random;
import java.util.Scanner;

public class Ex2 {
	int rand; 
	
	int Random() {
		Random random = new Random();
		random.setSeed(System.currentTimeMillis());
		rand = random.nextInt(11);
		return rand;
	}
	
	void bingo() {
		Scanner sc = new Scanner(System.in);
		int num;
		while(true) {
			System.out.print("숫자를 입력하세요 : ");
			num = sc.nextInt();
			
			if (num == rand) {
				System.out.println("-----------> 정답입니다. 축하합니다.");
				break;
			}
			else if (num > rand) {
				System.out.println("-----------> 숫자가 정답보다 높습니다.");
			}
			else if (num < rand) {
				System.out.println("-----------> 숫자가 정답보다 낮습니다.");
			}
		}
	}
	
	
	
	public static void main(String[] args) {
		Ex2 ex = new Ex2();
		ex.Random();
		ex.bingo();

	}

}
