package pk01;

import java.util.Scanner;

public class AppEx2 {
	String name;
	int[] score; 
	int total; 
	double avg;
	String npass;
	
	void input() {
		Scanner s = new Scanner(System.in);
		int size;
		System.out.print("이름과 배열의 개수를 입력하세요 : ");
		name = s.next();
		size = s.nextInt();
		
		score = new int[size];
		
		for (int i = 0; i < score.length; i++) {
			System.out.printf("[%d]: ", i);
			score[i] = s.nextInt();
		}
		s.close();
	}
	
	void process() {
		total = 0;
		for ( int i = 0; i <score.length;i++) {
			total += score[i]; 
		}
		avg = (double)total / score.length;
		npass = avg>= 80? "합격" : "불합격";
	}
	

	void print() {
		System.out.printf("[%s] 님의 점수는 " , name);
		
		for (int i = 0; i < score.length; i++) {
			System.out.print(score[i]);
			
			if (i != score.length-1)
				System.out.print(" ,");
			else
				System.out.println(" 이고");
		}
		System.out.printf("총점 : [%d], 평균 : [%.2f]으로 [%s]하셨습니다. ", total, avg, npass);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AppEx2 e = new AppEx2();
		
		e.input();
		e.process();
		e.print();
	
	}

}
