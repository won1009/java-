/*
 * 사용자의 이름과 점수를 입력받아 평균을 출력하는 프로그램
 */
package pk01;
import java.util.Scanner;

public class AppEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		String name;
		int size;
		int[] score; 
		int total; 
		double avg;
		String npass;
		
		System.out.print("이름과 배열의 개수를 입력하세요 : ");
		name = s.next();
		size = s.nextInt();
		
		score = new int[size];
		
		for (int i = 0; i < score.length; i++) {
			System.out.printf("[%d]: ", i);
			score[i] = s.nextInt();
		}
		s.close();
		
		total = 0;
		for ( int i = 0; i <score.length;i++) {
			total += score[i]; 
		}
		
		avg = (double)total / score.length;
		
		npass = avg>= 80? "합격" : "불합격";
		
		System.out.printf("[%s] 님의 점수는 " , name);
		
		for (int i = 0; i < score.length; i++) {
			System.out.print(score[i]);
			
			if (i != score.length-1)
				System.out.print(" ,");
			else
				System.out.println(" 이고");
		}
		System.out.printf("총점 : [%d], 평균 : [%.2f]으로 [%s]하셨습니다. ", total, avg, npass);
	}

}
