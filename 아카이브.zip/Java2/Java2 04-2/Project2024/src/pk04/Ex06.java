package pk04;
//추상 클래스가 적용된 객체 지향적 프로그램 구조

public class Ex06 extends Ex05Abstract { //객체 지향적 구조
	
	public Ex06() {
		input();
		process();
		print();
	}
	
	@Override
	public void input() {
		test1 = 78.0;
		test2 = 85.0;
		test3 = 90.7;
	}
	
	@Override
	public void process(){
		sum = test1 + test2 + test3;
		avg = sum / 3;
		
		if (avg >= 90) hak = 'A';
		else if (avg >= 80) hak = 'B';
		else if (avg >= 70) hak = 'C';
		else if (avg >= 60) hak = 'D';
		else hak = 'F';
	}
	
	public static void main(String[] args) {
		new Ex06();
		
	}

}
