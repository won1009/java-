package pk04;
//인터페이스가 적용된 객체 지향적 프로그램 구조
interface Ex04Inter{
	void input();
	void process();
}

public class Ex04 extends Ex03Data implements Ex04Inter{ //객체 지향적 구조
	
	@Override
	public void input() {
		test1 = 78.0;
		test2 = 85.0;
		test3 = 90.7;
	}
	
	@Override
	public void process(){
		sum = test1 + test2 + test3;
		avg = sum / 3;
		
		if (avg >= 90) hak = 'A';
		else if (avg >= 80) hak = 'B';
		else if (avg >= 70) hak = 'C';
		else if (avg >= 60) hak = 'D';
		else hak = 'F';
	}
	
	public static void main(String[] args) {
		Ex04 e = new Ex04();
		e.input();
		e.process();
		e.print();
	}

}
