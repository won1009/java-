package pk04;
//추상 클래스가 적용된 객체 지향적 프로그램 구조

abstract class Ex05Abstract{
	double test1, test2, test3;
	double avg, sum;
	char hak;
	
	void print() {
		System.out.printf("입력된 정수는 %.1f, %.1f, %.1f 이고\n", test1, test2, test3);
		System.out.printf("총점 : %.2f\n평균 : %.2f\n학점 : %c\n입니다.\n", sum, avg, hak);
	}
	
	abstract void input();
	abstract void process();
}

public class Ex05 extends Ex05Abstract { //객체 지향적 구조
	
	@Override
	public void input() {
		test1 = 78.0;
		test2 = 85.0;
		test3 = 90.7;
	}
	
	@Override
	public void process(){
		sum = test1 + test2 + test3;
		avg = sum / 3;
		
		if (avg >= 90) hak = 'A';
		else if (avg >= 80) hak = 'B';
		else if (avg >= 70) hak = 'C';
		else if (avg >= 60) hak = 'D';
		else hak = 'F';
	}
	
	public static void main(String[] args) {
		Ex05 e = new Ex05();
		e.input();
		e.process();
		e.print();
	}

}
