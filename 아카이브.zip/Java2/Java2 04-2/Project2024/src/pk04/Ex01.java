package pk04;

public class Ex01 { // 절차적 구조

	public static void main(String[] args) {
		double test1, test2, test3;
		double avg, sum;
		char hak;
		
		test1 = 78.0;
		test2 = 85.0;
		test3 = 90.7;
		
		sum = test1 + test2 + test3;
		avg = sum / 3;
		
		if (avg >= 90) hak = 'A';
		else if (avg >= 80) hak = 'B';
		else if (avg >= 70) hak = 'C';
		else if (avg >= 60) hak = 'D';
		else hak = 'F';
		
		System.out.printf("입력된 정수는 %.1f, %.1f, %.1f 이고\n", test1, test2, test3);
		System.out.printf("총점 : %.2f\n평균 : %.2f\n학점 : %c\n입니다.\n", sum, avg, hak);
	}

}
