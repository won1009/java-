package pk06;
enum Month {
	Jan,
	Feb,
	Mar,
	Apr,
	May,
	Jun,
	Jul,
	Aug,
	Sep,
	Oct,
	Nov,
	Dec
}

public class Ex1 {
	public static void main(String[] args) {
		Month currentMonth = Month.Apr;
		
		switch (currentMonth) {
		case Jan:
			System.out.println("지금은 1월 입니다!");
			break;
		case Feb:
			System.out.println("지금은 2월 입니다!");
			break;
		case Mar:
			System.out.println("지금은 3월 입니다!");
			break;
		case Apr:
			System.out.println("지금은 4월 입니다!");
			break;
		case May:
			System.out.println("지금은 5월 입니다!");
			break;
		case Jun:
			System.out.println("지금은 6월 입니다!");
			break;
		case Jul:
			System.out.println("지금은 7월 입니다!");
			break;
		case Aug:
			System.out.println("지금은 8월 입니다!");
			break;
		case Sep:
			System.out.println("지금은 9월 입니다!");
			break;
		case Oct:
			System.out.println("지금은 10월 입니다!");
			break;
		case Nov:
			System.out.println("지금은 11월 입니다!");
			break;
		case Dec:
			System.out.println("지금은 12월 입니다!");
			break;
		}
		for (Month month : Month.values()) {
			System.out.println(month);
		}
	}

}
