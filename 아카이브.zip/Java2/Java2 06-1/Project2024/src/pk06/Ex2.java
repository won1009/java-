package pk06;
enum Language {
	JAVA,
	Python,
	C,
	CPP,
	JS
}
public class Ex2 {

	public static void main(String[] args) {
		Language currentLanguage = Language.JAVA;
		
		switch(currentLanguage) {
		
		case JAVA:
			System.out.println("지금 배우는 언어는 JAVA입니다!");
			break;
		case C:
			System.out.println("지금 배우는 언어는 C입니다!");
			break;
		case Python:
			System.out.println("지금 배우는 언어는 Python입니다!");
			break;
		case CPP :
			System.out.println("지금 배우는 언어는 CPP입니다!");
			break;
		case JS :
			System.out.println("지금 배우는 언어는 JS입니다!");
			break;
		}
		
		for (Language language : Language.values()) {
			System.out.println(language);
		}
	}

}
