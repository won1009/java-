package pk12;

public class Ex03<T> {
    private T a, b;
    // 두 개의 데이터를 설정하는 메서드
    public void eData(T a, T b) {
        this.a = a;
        this.b = b;
    }

    // 데이터를 출력하는 메서드
    public void print() {
        System.out.println("a = " + a + ", b = " + b);
    }

    public static void main(String[] args) {
        // Integer 타입을 사용하는 Ex03 객체 생성 및 사용
        Ex03<Integer> intEx = new Ex03<>();
        intEx.eData(10, 20);
        intEx.print();  // a = 10, b = 20 출력

        // Double 타입을 사용하는 Ex03 객체 생성 및 사용
        Ex03<Double> doubleEx = new Ex03<>();
        doubleEx.eData(10.5, 20.8);
        doubleEx.print();  // a = 10.5, b = 20.8 출력
        
        // String 타입을 사용하는 Ex03 객체 생성 및 사용
        Ex03<String> stringEx = new Ex03<>();
        stringEx.eData("왕", "신하");
        stringEx.print();  // a = 왕, b = 신하 출력
        
        // Boolean 타입을 사용하는 Ex03 객체 생성 및 사용
        Ex03<Boolean> booleanEx = new Ex03<>();
        booleanEx.eData(true, false);
        booleanEx.print();  // a = true, b = false 출력
    }
}
