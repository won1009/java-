package pk12;

public class Ex02<T, U> {
    private T data;
    private U ename;

    // 첫 번째 데이터 설정 메서드


    // 첫 번째 데이터 반환 메서드
    public T getData() {return data;  }
    public void setEname(U ename) { this.ename = ename;}

    // 두 번째 데이터 반환 메서드
    public U getEname() {return ename;}
    public void setData(T data) {this.data = data;}
    
    
    public void eprint() {
        System.out.println("data = " + data + ", ename = " + ename);
    }

    public static void main(String[] args) {
        // Integer와 String 타입을 사용하는 Ex02 객체 생성 및 사용
        Ex02<Integer, String> k = new Ex02<>();
        
        k.setData(10);
        k.setEname("홍길동");
        k.eprint();  // data = 10, ename = 홍길동 출력
    }
}

