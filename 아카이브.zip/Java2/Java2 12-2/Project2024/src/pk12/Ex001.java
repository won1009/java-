package pk12;

public class Ex001<T> {
    private T data;
    // 데이터를 설정하는 메서드
    public T setData(T data) {
        this.data = data;
        return data;
    }

    // 데이터를 반환하는 메서드
    public T getData() {
        return data;
    }

    // 데이터를 출력하는 메서드
    public void eprint() {
        System.out.println("data = " + data);
    }

    public static void main(String[] args) {
        // Integer 타입의 Ex001 객체 생성 및 사용
        Ex001<Integer> k1 = new Ex001<>();
        k1.setData(10);
        k1.eprint();

        // Double 타입의 Ex001 객체 생성 및 사용
        Ex001<Double> k2 = new Ex001<>();
        k2.setData(50.7);
        k2.eprint();

        // String 타입의 Ex001 객체 생성 및 사용
        Ex001<String> k3 = new Ex001<>();
        k3.setData("홍길동");
        k3.eprint();
    }
}
