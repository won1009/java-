package pk12;

public class Ex01 {

    public int setData(int intData) {
        return intData;
    }

    public double setData(double doubleData) {
        return doubleData;
    }
    public String setData(String stringData) {
        return stringData;
    }

    public void eprint1(int data) {
        System.out.println("data = " + data);
    }

    public void eprint2(double data) {
        System.out.println("data = " + data);
    }


    public void eprint3(String data) {
        System.out.println("data = " + data);
    }

    public static void main(String[] args) {
        Ex01 k = new Ex01();

        // setData 메서드로 설정한 데이터를 eprint 메서드를 사용하여 출력
        k.eprint1(k.setData(10));      // int 데이터 출력
        k.eprint2(k.setData(50.7));    // double 데이터 출력
        k.eprint3(k.setData("홍길동")); // String 데이터 출력
    }
}
