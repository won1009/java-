package sec01.exam08;

import sec03.exam05_deep_clone.Car;

public class ClassExample {

	public static void main(String[] args) {
		//첫 번째 방법
		Class clazz = Car.class;
		
		//두 번째 방법
		//Class clazz = Class.forName("sec01.exam08.car");
		
		//세 번쨰 방법
		//Car car = new Car();
		//Class clazz = car.getClass();
		
		System.out.println(clazz.getName());
		System.out.println(clazz.getSimpleName());
		System.out.println(clazz.getPackage().getName());
	}

}
