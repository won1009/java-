package sec01.exam09;

public class Car {
public String model;
	
	public Car(String model) { 
		this.model = model;
	}
}
