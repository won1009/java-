package pk12;

public class MyArrayAlgTest {

	public static void main(String[] args) {
		String[] language = {"C++", "C", "JAVA"};
		String last = MyArrayAlg.getLast(language);
		System.out.println(last);

	}

}
