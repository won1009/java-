package pk12;

import java.util.HashMap;
import java.util.Map;

public class MapTest {

	public static void main(String[] args) {
		Map<String, String> map = new HashMap<String, String>();
		
		map.put("kim", "1234");
		map.put("park", "pass");
		map.put("lee", "ward");
		
		System.out.println(map.get("lee"));
		
		for(String key : map.keySet()) {
			String value = map.get(key);
			System.out.println("key=" + key + ", value=" + value);
		}
		
		map.remove(3);
		map.put("choi", "passward");
		System.out.println(map);
	}

}
