package pk13;

import java.io.*;

public class IOTest2 {
	public static void main(String[] args) {
		String fileName = "./file_data/org.txt";
		String line = null;
		
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			
			while((line = br.readLine()) != null)
				System.out.println(line);
			
			fr.close();
			br.close();
		} catch (FileNotFoundException ex) {
			System.out.println(fileName + " 파일을 열 수 없습니다.");
		} catch (IOException ex) {
			System.out.println(fileName + " 파일을 읽을 수 없습니다.");
		}
	}
}
