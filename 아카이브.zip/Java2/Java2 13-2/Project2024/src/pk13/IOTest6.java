package pk13;

import java.io.*;
import java.nio.file.Files;

public class IOTest6 {
	public static void main(String[] args) throws Exception {
		File f1 = new File("./file_data/org.txt");
		File f2 = new File("./file_data");
		
		System.out.println("org.txt는 폴더? " + Files.isDirectory(f1.toPath()));
		System.out.println("file_data는 폴더? " + Files.isDirectory(f2.toPath()));
		
		System.out.println("org.txt는 읽을 수 있는 파일? " + Files.isReadable(f1.toPath()));
		System.out.println("org.txt의 크기? " + Files.size(f1.toPath()));
	}
}
