package pk13;

import java.io.*;

public class ReadLineExample {

	public static void main(String[] args) throws Exception{
		String fileName = "./file_data/language.txt";
		String line = null;
		FileReader fr = new FileReader(fileName);
		BufferedReader br = new BufferedReader(fr);
		
		while((line = br.readLine()) != null)
			System.out.println(line);
		
		fr.close();
		br.close();
		
		/*
		 * Reader reader = new FileReader("./file_data/language.txt);
		 * BufferedReader br = new BufferedReader(reader);
		 * 
		 * while(true)
		 * 	String data = br.readLine();
		 * 	if(data == null) break;
		 * 	System.out.println(data);
		 * br.close();
		 */
	}

}
