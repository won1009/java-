package pk13;
import java.io.*;
public class IOTest5 {
	public static void main(String[] args) throws Exception {
		String filePath = "./src/pk13/IOTest5.java";
		FileReader fr = new FileReader(filePath);
		BufferedReader br = new BufferedReader(fr);
		int rowNumber = 0;
		String rowData;
		while( (rowData = br.readLine()) != null) {
			System.out.println(++rowNumber + " : " + rowData);
		}
		br.close();
	}
}