package pk13;

import java.io.*;
public class CopyFileDemo {

	public static void main(String[] args) {
		String input = "./file_data/org.txt";
		String output = "./file_data/org2.txt";
		
		try (FileReader fr = new FileReader(input);
			FileWriter fw = new FileWriter(output);) {
			int c;
			
			while ((c = fr.read()) != -1)
					fw.write(c);
		} catch (Exception e) {
		}
	}

}
