package pk13;

import java.io.*;

public class IOTest {
    public static void main(String[] args) {
    	String fileName = "./file_data/org.txt";
        
        try (
        	FileInputStream fis = new FileInputStream(fileName);
            BufferedInputStream bis = new BufferedInputStream(fis)) {
            
            byte[] buf = new byte[100];
            int bytesRead;
            while ((bytesRead = bis.read(buf)) != -1) 
                System.out.print(new String(buf, 0, bytesRead)); 
            
        } catch (FileNotFoundException ex) {
			System.out.println(fileName + " 파일을 열 수 없습니다.");
		} catch (IOException ex) {
			System.out.println(fileName + " 파일을 읽을 수 없습니다.");
		}
    }
}
