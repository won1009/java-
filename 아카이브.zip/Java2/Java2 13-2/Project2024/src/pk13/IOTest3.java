package pk13;

import java.io.*;
import java.nio.file.Files;
/*
 * NIO(Non-blocking I/O)는 자바에서 제공하는 I/O (Input/Output) 기능 중 하나입니다. 
 * 이는 기존의 전통적인 I/O보다 효율적인 입출력을 가능하게 합니다. NIO는 블로킹과 넌블로킹 방식의 입출력을 모두 지원합니다.
 * NIO의 핵심 개념은 채널(Channel)과 버퍼(Buffer)입니다. 채널은 데이터가 입출력되는 통로로, 
 * 버퍼는 데이터가 임시로 저장되는 공간입니다. NIO는 이러한 채널과 버퍼를 이용하여 입출력을 수행하며, 
 * 이를 통해 더 효율적인 입출력 및 병렬 처리가 가능해집니다.NIO는 다수의 클라이언트를 동시에 처리할 때 유용하며, 
 * 네트워크 프로그래밍이나 파일 입출력 등 다양한 상황에서 활용됩니다. NIO 패키지는 java.nio 패키지에 속해 있습니다.
 */

public class IOTest3 {
	public static void main(String[] args) {
		String fileName = "./file_data/org.txt";
		
		try {
			Files.lines(new File(fileName).toPath()).forEach(d -> System.out.println(d));
		} catch (FileNotFoundException ex) {
			System.out.println(fileName + " 파일을 열 수 없습니다.");
		} catch (IOException ex) {
			System.out.println(fileName + " 파일을 읽을 수 없습니다.");
		}
	}
}
