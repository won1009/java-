package pk01;

public class AppEx3 {
	String name; 
	int age;
	
	void eInit(){  // 메소드 만들기
		name = "홍길동";
		age = 100;
	}
	
	void eInit(String name){  // 메소드 만들기
		this.name = name;
		age = 100;
	}
	
	void eInit(int age){  // 메소드 만들기
		name = "홍길동";
		this.age = age;
	}
	
	void eInit(String name, int age){  //메소드 만들기
		this.name = name;
		this.age = age;
	}
	
	void ePrint() {
		System.out.println("당신의 이름은 " + name + ", 나이는 " + age + "세 입니다.");
	}
	
	public static void main(String[] args) {
		AppEx3 k1 = new AppEx3();
		
		k1.eInit();
		k1.ePrint();
		
		k1.eInit("이만두");
		k1.ePrint();
		
		k1.eInit(200);
		k1.ePrint();
		
		k1.eInit("최춘천", 300);
		k1.ePrint();
	}
}
