package pk01;

public class AppEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name;
		int age;
		
		name = "홍길동";
		age = 100;
		
		System.out.println("당신의 이름은 " + name + ", 나이는 " + age + "세 입니다.");
	}

}
