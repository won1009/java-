package pk01;

public class AppEx2 {
	String name; 
	int age;
	
	AppEx2(){  // 생성자 만들기
		name = "홍길동";
		age = 100;
	}
	
	AppEx2(String name){  // 생성자 만들기
		this.name = name;
		age = 100;
	}
	
	AppEx2(int age){  // 생성자 만들기
		name = "홍길동";
		this.age = age;
	}
	
	AppEx2(String name, int age){  // 생성자 만들기
		this.name = name;
		this.age = age;
	}
	
	void ePrint() {
		System.out.println("당신의 이름은 " + name + ", 나이는 " + age + "세 입니다.");
	}
	
	public static void main(String[] args) {
		AppEx2 k1 = new AppEx2();
		k1.ePrint();
		
		AppEx2 k2 = new AppEx2("이만두");
		k2.ePrint();
		
		AppEx2 k3 = new AppEx2(200);
		k3.ePrint();
		
		AppEx2 k4 = new AppEx2("최춘천", 300);
		k4.ePrint();
	}

}
