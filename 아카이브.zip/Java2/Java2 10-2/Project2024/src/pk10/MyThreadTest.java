package pk10;

class MyThread extends Thread{
	public void run() {
		System.out.println("내가 호출될거야....");
	}
}

public class MyThreadTest {

	public static void main(String[] args) {
		MyThread t = new MyThread();
		
		t.start();
	}

}
