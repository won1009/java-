package pk10;

class MyThread2 extends Thread{
	public void run() {
		for (int i = 1; i <= 10; i++) {
			System.out.print(i + "...");
		}
	}
}

public class MyThreadTest2 {

	public static void main(String[] args) {
		MyThread2 t = new MyThread2();
		
		t.start();
		System.out.println("난 main()에서 출력된거야~");
	}

}
