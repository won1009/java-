package pk07;
import java.util.Scanner;

public class Ex5 {
    double sum;
    double avg;
    char hak;
    double arr[];
    

    public void process() {
        arr = new double[5];
        Scanner sc = new Scanner(System.in);
        System.out.print("점수를 입력하세요 : ");
        for(int i = 0; i < arr.length; i++) {
            arr[i] = sc.nextDouble();
            sum += arr[i];
        }
        avg = sum / arr.length;
        
        if (avg >= 90) hak = 'A';
        else if (avg >= 80) hak = 'B';
        else if (avg >= 70) hak = 'C';
        else if (avg >= 60) hak = 'D';
        else hak = 'F';
            
        System.out.printf("점수는 %.2f, 평균은 %.2f 따라서 학점은 %c입니다." ,sum, avg, hak);
    }
    
    public static void main(String[] args) {
        Ex5 ex = new Ex5();
        ex.process();
    }
}
