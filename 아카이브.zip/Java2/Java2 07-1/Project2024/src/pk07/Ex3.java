package pk07;

abstract class Ex3Abs{
	int[] arr;
	abstract void sort();
}

public class Ex3 extends Ex3Abs{

	@Override
	public void sort() {
		arr = new int[] {10, 30, 25, 5, 50, 20};
		for (int i = 0; i < arr.length-1; i++) {
			for (int k = i + 1; k < arr.length; k++) {
				if (arr[i] > arr[k]) {
					int tmp;
					tmp = arr[i];
					arr[i] = arr[k];
					arr[k] = tmp;
				}
			}
		}	
		
		for (int d : arr) 
			System.out.print(d + " ");
		
	}
	
	
	public static void main(String[] args) {
		Ex3 ex = new Ex3();
		ex.sort();
	}
}
