package pk07;
import java.util.Scanner;

interface Ex4Inter{
	void EvenOdd();
	void print();
}

public class Ex4 implements Ex4Inter{
	String str;
	int odd, even;
	
	@Override
	public void EvenOdd() {
		Scanner sc = new Scanner(System.in);
		System.out.print("영문 문자열을 입력하세요 : ");
		str = sc.nextLine();
		String vowels = "aeiouAEIOU";
		
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if (vowels.indexOf(ch) != -1) {
				even++;
			}
			else if (ch == ' ') {
				continue;
			}
			else {
				odd++;
			}
		}
	}
	
	@Override
	public void print() {
		System.out.printf("자음은 %d개, 모음은 %d개 입니다.", odd, even);
	}
	
	public static void main(String[] args) {
		Ex4 ex = new Ex4();
		ex.EvenOdd();
		ex.print();
	}

}
