package pk07;

public class Ex2 {
	int x = 10;
	int y = 20; 
	int tmp;
	
	void eswap() {
		tmp = x;
		x = y;
		y = tmp;
	}
	
	void eprint() {
		System.out.println("x=" + x +", y=" + y);
	}
	
	public static void main(String[] args) {
		Ex2 k = new Ex2();
		
		k.eprint();
		k.eswap();
		k.eprint();
	}

}
