// Shape 클래스 정의
class Shape {
    protected int width;
    protected int height;

    // 생성자
    public Shape(int width, int height) {
        this.width = width;
        this.height = height;
    }

    // 넓이 계산 메소드
    public int calculateArea() {
        return width * height;
    }
}

// Shape을 상속받는 Rectangle 클래스 정의
class Rectangle extends Shape {
    // 생성자
    public Rectangle(int width, int height) {
        // 부모 클래스의 생성자 호출
        super(width, height);
    }
}

// 메인 클래스
public class Ex1 {
    public static void main(String[] args) {
        // Rectangle 객체 생성
        Rectangle rectangle = new Rectangle(5, 10);

        // 넓이 계산 및 출력
        int area = rectangle.calculateArea();
        System.out.println("Rectangle Area: " + area);
    }
}
