package pk03;

public class Ex4 {
	int x, y;
	
	void prt() {
		System.out.println("x = " + x + ", y = " + y);
	}
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	public static void main(String[] args) {
		Ex4 e = new Ex4();
		e.setX(100);
		e.setY(200);
		e.prt();
		
		System.out.println("x = " + e.getX() + ", y = " + e.getY());
	}

}
