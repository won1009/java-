package pk03;

import java.util.Scanner;
public class Ex6 extends Ex5Data{
	
	void input() {
		Scanner sc = new Scanner(System.in);
		System.out.print("x와 y의 값을 입력하세요 : ");
		x = sc.nextInt();
		y = sc.nextInt();
		sc.close();
	}
	
	public static void main(String[] args) {
		Ex6 e = new Ex6();
		// 키보드로 입력된  두 x,y값을 입력받아 출력하시오.
		
		e.input();
		e.prt();
	}
}
