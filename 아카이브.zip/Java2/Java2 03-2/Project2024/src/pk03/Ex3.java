package pk03;

public class Ex3 {
	private int x, y;
	
	void prt() {
		System.out.println("x = " + x + ", y = " + y);
	}
	
	public Ex3(){
		x = 10;
		y = 20;
	}
	
	void setX(int x) {
		this.x = x;
	}
	
	void setY(int y) {
		this.y = y;
	}
	
	int getX() {
		return x;
	}
	
	int getY() {
		return y;
	}
	
	public static void main(String[] args) {
		Ex3 k = new Ex3();
		
		k.prt();	
		
		k.x = 50;
		k.y = 60;
		k.prt();
		
		k.setX(100);
		k.setY(200);
		k.prt();

		System.out.println("x = " + k.getX() + ", y = " + k.getY());
	}

}
