package pk03;

public class Ex7 extends Ex5Data{
	Ex7(){
		x = 50;
		y =20;
	}
	Ex7(int x, int y ){
		this.x = x;
		this.y = y;
	}
	
	public static void main(String[] args) {
		Ex7 e = new Ex7();
		
		e.prt();
		
		e = new Ex7(100, 200);
		e.prt();
	}

}
