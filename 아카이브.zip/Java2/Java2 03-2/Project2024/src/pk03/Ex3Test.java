package pk03;

public class Ex3Test {
	public static void main(String[] args) {
		Ex3 k = new Ex3();
		
		k.prt();	
		
		k.setX(100);
		k.setY(200);
		k.prt();
		
		System.out.println("x = " + k.getX() + ", y = " + k.getY());
	}
}
