package pk03;

class Ex5Data {
	int x, y;
	
	void prt() {
		System.out.println("x = " + x + ", y = " + y);
	}
}

public class Ex5 extends Ex5Data{
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	public static void main(String[] args) {
		Ex5 e = new Ex5();
		e.setX(100);
		e.setY(200);
		e.prt();
		
		System.out.println("x = " + e.getX() + ", y = " + e.getY());
	}

}
