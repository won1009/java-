package pk03;

public class Ex2 {	//객체적 프로그램의 구조 설계 및 구현
	int x, y;
	
	void prt() {
		System.out.println("x = " + x + ", y = " + y);
	}
	
	public Ex2(){
		x = 10;
		y = 20;
	}
	
	
	
	public static void main(String[] args) {
		Ex2 k = new Ex2();
		
		k.prt();	
	}

}
