package pk03;

public class Ex1 {	//절차적 프로그램의 구조 설계 및 구현

	public static void main(String[] args) {
		int x, y;
		
		x = 10;
		y = 20;
		
		System.out.println("x = " + x + ", y = " + y);
	}

}
