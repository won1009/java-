package app;

import pk05.ExArray;
public class MainClass {

	public static void main(String[] args) {
		int[] arr = {10, 5, -5, 20, 100, 60, 78, 15, 87, 35};
		ExArray e = new ExArray();
		
		e.arrMethod(arr);
		e.print(arr);
	}

}
