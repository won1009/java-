package pk05;

public class ExArray {
	public void arrMethod(int[] arr) {
		for (int i = 0; i < arr.length-1; i++) {
			for (int k = i + 1; k < arr.length; k++) {
				if (arr[i] > arr[k]) {
					int tmp;
					tmp = arr[i];
					arr[i] = arr[k];
					arr[k] = tmp;
				}
			}
		}	
	}
	
	public void print(int[] arr) {
		for (int d : arr) 
			System.out.print(d + " ");
	}
	
	

}
