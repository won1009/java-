package pk05;

public class Ex1 {
	
	public static void main(String[] args) {
		int[] arr = {10, 5, -5, 20, 100, 60, 78, 15, 87, 35};
		//오름차순 정렬
		for (int i = 0; i < arr.length-1; i++) {
			for (int k = i + 1; k < arr.length; k++) {
				if (arr[i] > arr[k]) {
					int tmp;
					tmp = arr[i];
					arr[i] = arr[k];
					arr[k] = tmp;
				}
			}
		}	
		
		for (int d : arr) 
			System.out.print(d + " ");
		
		
			
	}

}
