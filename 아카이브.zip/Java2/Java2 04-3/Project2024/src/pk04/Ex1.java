package pk04;

import java.util.Scanner;

public class Ex1 {
    private int[] data;

    public void Input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("입력할 데이터 수는 ? ");
        int numData = scanner.nextInt();
        data = new int[numData];
        System.out.printf("%d개의 수를 입력하세요: ", numData);
        for (int i = 0; i < data.length; i++) {
            data[i] = scanner.nextInt();
        }
        scanner.close();
        System.out.println(" ");
    }

    public void SortAscending() {
        for (int i = 0; i < data.length - 1; i++) {
            for (int j = 0; j < data.length - i - 1; j++) {
                if (data[j] > data[j + 1]) {
                    int temp = data[j];
                    data[j] = data[j + 1];
                    data[j + 1] = temp;
                }
            }
        }
    }

    public void SortDescending() {
        for (int i = 0; i < data.length - 1; i++) {
            for (int j = 0; j < data.length - i - 1; j++) {
                if (data[j] < data[j + 1]) { 
                    int temp = data[j];
                    data[j] = data[j + 1];
                    data[j + 1] = temp;
                }
            }
        }
    }

    public void print() {
        System.out.print("오름차순으로 정렬 : ");
        for (int i = 0; i < data.length; i++) {
            System.out.print(data[i] + " ");
        }
        System.out.println();
        
        SortDescending(); 
        System.out.print("내림차순으로 정렬 : ");
        for (int i = 0; i < data.length; i++) {
            System.out.print(data[i] + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Ex1 ex = new Ex1();
        ex.Input();
        ex.SortAscending();
        ex.print();
    }
}
