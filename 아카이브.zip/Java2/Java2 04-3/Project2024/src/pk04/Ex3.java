package pk04;

import java.util.Scanner;

interface ConvertInter {
    String str(String input);
    int con(String input);
    int vow(String input);
    boolean isVowel(char c);
    void input();
    void print();
}

class conv implements ConvertInter {
    String inputStr;
    String convertedStr;
    int consonantCnt;
    int vowelCnt;

    @Override
    public String str(String input) {
        String result = "";
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' ') {
                if (c >= 'A' && c <= 'Z') {
                    c = (char) (c + ('a' - 'A'));
                }
                result += c;
            }
        }
        return result;
    }

    @Override
    public int con(String input) {
        int count = 0;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (!isVowel(c) && (c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z')) {
                count++;
            }
        }
        return count;
    }

    @Override
    public int vow(String input) {
        int count = 0;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (isVowel(c)) {
                count++;
            }
        }
        return count;
    }

    @Override
    public boolean isVowel(char c) {
        return "aeiouAEIOU".indexOf(c) != -1;
    }

    @Override
    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("영문 문자열을 입력하세요: ");
        inputStr = scanner.nextLine();
        scanner.close();

        convertedStr = str(inputStr);
        consonantCnt = con(convertedStr);
        vowelCnt = vow(convertedStr); 
    }

    @Override
    public void print() {
        System.out.println("소문자로 변환된 문자열: " + convertedStr);
        System.out.println("자음의 개수: " + consonantCnt + " 개");
        System.out.println("모음의 개수: " + vowelCnt + " 개");
    }
}

public class Ex3 {
    public static void main(String[] args) {
    	conv cv = new conv();

        cv.input();
        cv.print();
    }
}

