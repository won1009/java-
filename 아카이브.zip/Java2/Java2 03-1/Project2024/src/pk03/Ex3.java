package pk03;

import java.util.Scanner;

class DataPrint{	// 기본 소스
	String sign;
	int cnt;

	void prt() {
		for (int i = 1; i <= cnt; i++)
			System.out.printf("%-3s", sign); 
		System.out.println(" (" + cnt + ")");
	}
}


public class Ex3 extends DataPrint{

	
	void input() {
		Scanner sc = new Scanner(System.in);
		System.out.print("기호와 반복 개수를 입력하세요 : ");
		sign = sc.next();
		cnt = sc.nextInt();
		sc.close();
	}
		
		
		
	public static void main(String[] args) {
		Ex3 e1 = new Ex3();
		
		e1.input();
		e1.prt();
	}

}
