package pk03;
import java.util.Scanner;
public class Ex2 { // 프로그램 실행 중에 기호와 반복개수를 입력받아서 출력되도록 프로그램 하시오.  
	String sign;
	int cnt;
	
	void input() {
		Scanner sc = new Scanner(System.in);
		System.out.print("기호와 반복 개수를 입력하세요 : ");
		sign = sc.next();
		cnt = sc.nextInt();
		sc.close();
	}
	
	void prt() {
		for (int i = 1; i <= cnt; i++)
			System.out.printf("%-3s", sign); //3칸을 기준으로 좌측 정렬
		System.out.println(" (" + cnt + ")");
	}	
	
	public static void main(String[] args) {
		Ex2 e1 = new Ex2();
		
		e1.input();
		e1.prt();
	}

}
