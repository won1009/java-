package pk03;
/*
 * [출력 결과]
 *  #  #  #  #  #  #  #  #  #  # (10)
 * 	#  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  # (20)
 */
public class Ex1 {
	char sign; 
	int cnt;
	
	Ex1(char sign){
		this.sign = sign;
		cnt = 10;
	}
	
	Ex1(char sign, int cnt){
		this.sign = sign;
		this.cnt = cnt;
	}
	
	void prt() {
		for(int i = 1; i <= cnt; i++) 
			System.out.printf("%3c", sign); //3칸을 기준으로 우측 정렬
		System.out.println(" (" + cnt + ")");
	}
	public static void main(String[] args) {
		Ex1 e1 = new Ex1('#');
		Ex1 e2 = new Ex1('#', 20);
		
		e1.prt();
		e2.prt();

	}

}
