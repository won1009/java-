package pk09;
abstract class Ex4Abs{
	abstract void sort();
	abstract void print();
}
public class Ex4 extends Ex4Abs{
	int[] arr;
	
	Ex4() {
		arr = new int[]{100, -5, 30, 95, 30, 60, 23};
		sort();
		print();
	}
	@Override
	public void sort() {
		for (int i = 0; i < arr.length-1; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] > arr[j]) {
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
	}
	
	@Override
	public void print() {
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}
	public static void main(String[] args) {
		Ex4 ex = new Ex4();
		
	}

}
