package pk09;
import java.util.Scanner;
public class Ex5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int size;
		String[] arr; 
		
		System.out.print("배열의 크기는?");
		size = sc.nextInt();
		arr = new String[size];
		
		for (int i = 0; i < arr.length; i++) {
			System.out.print("이름은? ");
			arr[i] = sc.next();		
		}
		sc.close();
		
		for (int i = 0; i < size; i++) {
			System.out.print(arr[i] + " ");		
		}
	}

}
