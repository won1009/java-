package pk09;
import java.util.Scanner;
interface Ex3Inter {
	void process();
}
public class Ex3 implements Ex3Inter {
	Ex3() {
		process();
	}
	
	@Override
	public void process() {
		Scanner sc = new Scanner(System.in);
		int score;
		
		System.out.print("점수 입력 : ");
		score = sc.nextInt();
		
		if(score >= 60) System.out.println("합격");
		else System.out.println("불합격");
	}
	public static void main(String[] args) {
		Ex3 ex = new Ex3();
	}

}
