package pk09;
import java.util.Scanner;
public class Ex2 {
	private double[] arr;
	private double sum = 0;
	private char hak;
	
	Ex2() {
		input();
		process();
		print();
	}
	public void input() {
		Scanner sc = new Scanner(System.in);
		arr = new double[100];
		for (int i = 0; i < arr.length; i++) {
			System.out.println("점수 입력 : ");
			arr[i] = sc.nextDouble();
			sum += arr[i];
		}
		sc.close();
	}
	
	public void process() {
		double avg = sum/100;
		if (avg >= 90) hak = 'A';
		else if(avg >= 80) hak = 'B';
		else if(avg >= 70) hak = 'C';
		else if(avg >= 60) hak = 'D';
		else hak = 'F';
	}
	
	public void print() {
		System.out.printf("총합은 %f, 학점은 %c입니다.", sum, hak);
	}
	
	public static void main(String[] args) {
		Ex2 ex = new Ex2();
		
	}

}
