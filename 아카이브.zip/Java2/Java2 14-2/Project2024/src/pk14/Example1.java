package pk14;
import java.io.*;
import java.util.Scanner;
public class Example1 {

	public static void main(String[] args) throws Exception{
		Scanner sc = new Scanner(System.in);
		int num;
		
		System.out.print("입력할 학생 수 : ");
		num = sc.nextInt();
		sc.nextLine();
		
		String[] student = new String[num];
		
		for(int i = 0; i < student.length; i++ ) {
			System.out.print("학생이름과 나이[" + i +"];");
			student[i] = sc.nextLine();
		}
		
		sc.close();
		
		Writer wr = new FileWriter("./data_soc/source.txt");
		for (int i = 0; i < student.length; i++ ) {
			wr.write(student[i] + "\n");
		}
		
		wr.flush();
		wr.close();
	}

}
