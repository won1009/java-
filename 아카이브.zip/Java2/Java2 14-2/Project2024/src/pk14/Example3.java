package pk14;
import java.io.*;
public class Example3 {

	public static void main(String[] args) throws Exception{
		Reader reader = new FileReader("./data_soc/source.txt");
		BufferedReader br = new BufferedReader(reader);
		Writer wr = new FileWriter("./data_soc/김상성.txt");
		
		String name;
		int age;
		int count = 1;
		String adult;
		
		while(true) {
			String data = br.readLine();
			if (data == null) { 
                break;
            }
			String[] data2 = data.split(" ");
			name = data2[0];
	        age = Integer.parseInt(data2[1]);
	        adult = (age >= 18) ? "성년" : "미성년";
	        
	        String finalData = String.format("%d. 이름 : %s, 나이 : %d, 구분 : %s \n", count, name, age, adult);
	        wr.write(finalData);
	        count++;
		}
		
		br.close();
		wr.close();

	}

}
