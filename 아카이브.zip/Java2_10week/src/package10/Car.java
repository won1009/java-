package package10;

public class Car {

}
