package week11_java2;

public class StringIndexOfExample {
    public static void main(String[] args) {
       String str = "자바 프로그래밍";
       
       int location = str.indexOf("프로그래밍");
       System.out.println(location);

        // 문자열에 "자바"가 포함되어 있는지 확인
        if (str.indexOf("자바") != -1) {
            System.out.println("자바와 관련된 책이군요.");
        } else {
            System.out.println("자바와 관련된 책이 아니군요.");
        }
    }
}
