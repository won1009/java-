

package week11_java2;

import java.util.Scanner;


public class keyboardtostring {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // 키보드로부터 입력 받은 바이트 배열 생성
        byte[] bytes = scanner.nextLine().getBytes();
        
        // 키보드로부터 입력 받은 바이트 배열로부터 문자열 생성
        String str = new String(bytes);
        System.out.println("입력 : "
        		); // 입력한 문자열 출력

        // 일부 문자열 출력 (인덱스 0부터 5까지의 문자열)
        String strPartial = new String(bytes, 0, 5);
        System.out.println(strPartial); // "hello" 출력
    }
}

