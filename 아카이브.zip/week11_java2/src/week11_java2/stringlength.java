package week11_java2;

public class stringlength {
    public static void main(String[] args) {
        String jumin = "1234567890123"; // 주민등록번호 예시

        // 주민등록번호의 길이 확인
        if (jumin.length() == 13) {
            System.out.println("주민번호 자리수가 맞습니다.");
        } else {
            System.out.println("주민번호 자리수가 틀립니다.");
        }
    }
}
