package week11_java2;

public class NanoTime {
	    public static void main(String[] args) {
	        long startTime = System.nanoTime(); // 시작 시간 기록
	        
	        long sum = 0;
	        for (int i = 1; i <= 1000000; i++) {
	            sum += i;
	        }
	        
	        long endTime = System.nanoTime(); // 종료 시간 기록
	        long elapsedTime = endTime - startTime; // 경과 시간 계산
	        
	        System.out.println("1부터 1,000,000까지의 합: " + sum);
	        System.out.println("계산에 " + elapsedTime + " 나노초가 소요되었습니다.");
	    }
	}

