package week11_java2;
public class ByteToStringExample {
    public static void main(String[] args) {
        byte[] bytes = { 72, 101, 108, 108, 111, 32, 74, 97, 118, 97 };

        // byte 배열을 문자열로 변환
        String str1 = new String(bytes);
        System.out.println(str1); // 출력: Hello Java

        // 일부 문자열 출력
        String str2 = new String(bytes,6,4); // 출력: Java
        System.out.println(str2);
    }
}

