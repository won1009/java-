package week11_java2;

public class StringCharAt {
    public static void main(String[] args) {
        String str = "1234";

        // 첫 번째 문자 가져오기
        char ch = str.charAt(0);

        // switch 문을 사용하여 문자에 따라 결과 출력
        switch (ch) {
            case '1':
            case '3':
                System.out.println("남자입니다.");
                break;
            case '2':
            case '4':
                System.out.println("여자입니다.");
                break;
            default:
                System.out.println("잘못된 입력입니다.");
        }
    }
}

