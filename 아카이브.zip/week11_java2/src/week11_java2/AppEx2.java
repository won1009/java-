package week11_java2;

public class AppEx2 {

	public static void main(String[] args) {
		String str1 = null;
		String str2 = null;
		
		try {
			str1 = args[0];
			str2 = args[1];
			
			int va1 = Integer.parseInt(str1);
			int va2 = Integer.parseInt(str2);
			int result = va1 + va2;
			
			System.out.println(str1 + " + " + str2 + " = " + result);
			
		}catch (Exception e) {
			System.out.println("실행에 문제가 있습니다.");
		}
//		catch (ArrayIndexOutOfBoundsException e) {
//			System.out.println("매개 값이 없습니다. 프로그램을 종료합니다.");	
//		}catch (NumberFormatException e) {
//			System.out.println("숫자로 변환할 수 없습니다.\n다시 실행하세요.");
//		}
		finally {
			System.out.println("프로그램을 종료합니다.");
		}
		
	}

}
