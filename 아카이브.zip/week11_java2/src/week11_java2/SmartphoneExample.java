package week11_java2;

public class SmartphoneExample {


    public static void main(String[] args) {
        Smartphone myPhone = new Smartphone("구글" , "안드로이드");
        
        
        String strObj = myPhone.toString();
        System.out.println(strObj); // 출력 결과: Smartphone: 안드로이드
        
    
        System.out.println(myPhone); // 출력 결과: Smartphone: 구글
    }
}
