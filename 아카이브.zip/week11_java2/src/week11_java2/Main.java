package week11_java2;

class GotJ implements Cloneable {
    private String name;
    private int scores;
    private String car;

    public GotJ(String name, int scores, String car) {
        this.name = name;
        this.scores = scores;
        this.car = car;
    }

    @Override
    protected Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            System.out.println("복제 실패: " + e);
            return null;
        }
    }

    @Override
    public String toString() {
        return "GotJ{name='" + name + "', scores=" + scores + ", car='" + car + "'}";
    }
}

