package week11_java2;


public class Exit {
    public static void main(String[] args) {
        // SecurityManager의 checkExit 메서드 오버라이딩
        System.setSecurityManager(new SecurityManager() {
        	
            @Override
            public void checkExit(int status) {
                if (status != 5) {
                    throw new SecurityException();
                }
            }
        });

        // 반복문을 사용하여 10보다 작을 때까지 exit 호출
        for (int i = 0; i < 10; i++) {
            System.out.println(i);
            try {
                System.exit(i);
            } catch (SecurityException e) {}
        }
    }
}
