package week11_java2;

@SuppressWarnings("serial")
class MyException extends Exception{
	public MyException() {
		super("내가 만든 사용자 정의 예외 클래스");
	}
}

public class AppEx3 {
	
	public void mtMethod() throws MyException{
		throw new MyException();
	}
	
	public static void main(String[] args) {
		AppEx3 k = new AppEx3();
		
		try {
			k.mtMethod();
		} catch (MyException e) {
			System.err.println(e.getMessage() + ":::");
			System.out.println("호출스택내용 : ");
			e.printStackTrace();
		}

	}

}
