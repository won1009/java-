package week11_java2;

public class cloneexample {

	    public static void main(String[] args) {
	        GotJ original = new GotJ("KangDaniel", 95, "BMW");

	        GotJ cloned = (GotJ) original.clone();

	        System.out.println("Original: " + original);
	        System.out.println("Cloned: " + cloned);
	    }
	}
