package Java2_6week;

class Parent {
    String field1;

    void method1() {
        System.out.println("Method1 from Parent");
    }

    void method2() {
        System.out.println("Method2 from Parent");
    }
}

class Child extends Parent {
    String field2;

    void method3() {
        System.out.println("Method3 from Child");
    }

    void method4() {
        System.out.println("Method4 from Child");
    }
}

public class Main3 {
    public static void main(String[] args) {
       
        Parent parent = new Child();

        
        parent.method1(); // Output: Method1 from Parent
        parent.method2(); // Output: Method2 from Parent

     
        Child child = (Child) parent;
        child.field2 = "yyy"; 
        child.method3(); // Output: Method3 from Child
        child.method4(); // Output: Method4 from Child
    }
}
