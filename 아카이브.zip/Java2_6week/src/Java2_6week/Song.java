package Java2_6week;

class Animal {
    public void sound() {
        System.out.println("동물합창단");
    }
}

class Dog extends Animal {
    @Override
    public void sound() {
        System.out.print("강아지가 노래를 합니다: ");
    }

    public void dogsound() {
        System.out.println("Dog.. Dog..");
    }
}

class Cat extends Animal {
    @Override
    public void sound() {
        System.out.print("고양이가 노래를 합니다: ");
    }

    public void catsound() {
        System.out.println("Cat.. Cat..");
    }
}

public class Song {
    public static void main(String[] args) {
        Animal dog = new Dog();  
        Animal cat = new Cat();

        if (dog instanceof Dog) {
        	Dog specificDog = (Dog)dog;
        	specificDog.sound();
        	specificDog.dogsound();
        }
         
      
        if (cat instanceof Cat) {
        	Cat specificDog = (Cat)cat;
        	specificDog.sound();
        	specificDog.catsound();
        }
    }
}
