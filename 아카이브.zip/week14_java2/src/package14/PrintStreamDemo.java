package package14;

import java.io.*;
import java.io.FileWriter;


public class PrintStreamDemo {
    public static void main(String[] args) {
        try (BufferedReader br = new BufferedReader(new FileReader("data_src/org.txt"));
             PrintWriter pr = new PrintWriter(new FileWriter("data_src/org.txt"))) {
            
        	br.lines().forEach(x->pr.println(x));
        } catch (IOException e) {
        }
    }
}
