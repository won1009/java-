package package14;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyFileDemo {
    public static void main(String[] args) {
        String input = "./resource/soc.txt";  // 입력 파일 경로
        String output = "./resource/source.txt"; // 출력 파일 경로

        // 파일 복사
        try (FileInputStream fis = new FileInputStream(input);
             FileOutputStream fos = new FileOutputStream(output)) {
            

            int c;
            
            while ((c = fis.read()) != -1) {
                fos.write(c);
            }
        } catch (IOException e) { }
    }
}
