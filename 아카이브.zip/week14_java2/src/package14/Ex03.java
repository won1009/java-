package package14;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Ex03 {
    public static void main(String[] args) {
        try (
            BufferedReader reader = new BufferedReader(new FileReader("source.txt"));
            FileWriter writer = new FileWriter("result2.txt")
        ) {
            String line;
            int count = 1; // 학생 번호를 위한 변수
            
            while ((line = reader.readLine()) != null) {
                // 파일에서 읽은 한 줄을 공백으로 분리
                String[] parts = line.split(" ");
                String name = parts[0]; // 이름
                int age = Integer.parseInt(parts[1]); // 나이
                
                // 성년/미성년 판별
                String status = (age >= 18) ? "성년" : "미성년";
                
                // 결과 문자열 생성
                String result = String.format("%d. 이름 : %s, 나이 : %d세, 구분 : %s", count, name, age, status);
                
                // 파일에 저장
                writer.write(result + "\n");
                
                count++; // 번호 증가
            }
            
            System.out.println("결과가 result2.txt에 저장되었습니다.");
        } catch (IOException e) {
            System.out.println("오류 발생: " + e.getMessage());
        }
    }
}
