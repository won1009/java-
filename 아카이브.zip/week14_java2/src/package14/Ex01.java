package package14;

import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;

public class Ex01 {
    public static void main(String[] args) {
        int number;
        Scanner in = new Scanner(System.in);
        
        // 학생 수 입력
        System.out.print("입력할 학생수 : ");
        number = in.nextInt();
        in.nextLine(); // 버퍼 비우기

        try (FileWriter Write = new FileWriter("source.txt")) { // FileWriter 초기화
            for (int i = 0; i < number; i++) {
                System.out.print("학생 이름과 나이[" + i + "] : ");
                String input = in.nextLine();
                
                // FileWriter로 입력 저장
                Write.write(input + "\n");
            }
        } catch (IOException e) {
            System.out.println("오류 발생: " + e.getMessage());
        }

        in.close(); // Scanner 닫기
    }
}
