package package14;

import java.io.File;
import java.nio.file.Files;

public class FilesDemo {
    public static void main(String[] args) throws Exception {
        // 파일 및 폴더 경로 설정
        File f1 = new File("./data_src/org.txt");
        File f2 = new File("./data_src");

        // org.txt는 폴더인지 확인
        System.out.println("org.txt는 폴더? " + Files.isDirectory(f1.toPath()));

        // data_src는 폴더인지 확인
        System.out.println("data_src는 폴더? " + Files.isDirectory(f2.toPath()));

        // org.txt는 읽을 수 있는 파일인지 확인
        System.out.println("org.txt는 읽을 수 있는 파일? " + Files.isReadable(f1.toPath()));
        System.out.println("org.txt의 크기: " + Files.size(f1.toPath()));
      
        }
    }
