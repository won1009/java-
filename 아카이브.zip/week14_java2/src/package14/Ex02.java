/*
 * [문제2]에서 작성된 “source.txt”파일을 이용하여 아래 [출력결과]와 같이 보이도록 프로그램 하세요.
조건 : 성년의 기준은 만18세 이상, 그 외는 미성년

[출력결과]
[홍길동]님의 나이는 [15]세로 [미성년]입니다.
[이만두]님의 나이는 [19]세로 [성년]입니다.
[박길자]님의 나이는 [17]세로 [미성년]입니다.
 */
package package14;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Ex02 {
    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new FileReader("source.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {  // 파일에서 읽은 한 줄을 공백으로 분리
                String[] parts = line.split(" ");
                String name = parts[0]; // 이름
                int age = Integer.parseInt(parts[1]); // 나이
                
                // 성년/미성년 판별
                String status = (age >= 18) ? "성년" : "미성년";
                
                // 출력 결과
                System.out.printf("[%s]님의 나이는 [%d]세로 [%s]입니다.%n", name, age, status);
            }
        } catch (IOException e) {
            System.out.println("파일 읽기 중 오류 발생: " + e.getMessage());
        }
    }
}
