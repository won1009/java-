package package14;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataStreamDemo {
    public static void main(String[] args) {
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream("./resource/soc.txt"));
             DataInputStream dis = new DataInputStream(new FileInputStream("./resource/soc.txt"))) {
            
            // 데이터 쓰기
            dos.writeInt(20);           // 정수 쓰기
            dos.writeDouble(34.5);      // 실수 쓰기
            dos.writeUTF("Hello");      // 문자열 쓰기
            
            dos.flush(); // DataOutputStream에 대해 flush 수행
            
            // 데이터 읽기
            System.out.println(dis.readInt());
            System.out.println(dis.readDouble());
            System.out.println(dis.readUTF());
     
            
        } catch (IOException e) {
         
        }
    }
}

	/*
    public static void main(String[] args) {
        String outputFile = "./resource/data_output.txt"; // 출력 파일 경로
        String inputFile = "./resource/data_output.txt";  // 입력 파일 경로

        // 데이터 쓰기 (DataOutputStream)
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(outputFile))) {
            dos.writeInt(12345);           // 정수 쓰기
            dos.writeDouble(123.45);       // 실수 쓰기
            dos.writeUTF("Hello, World!"); // 문자열 쓰기
            System.out.println("데이터가 파일에 성공적으로 기록되었습니다.");
        } catch (IOException e) {
            System.err.println("데이터 쓰기 중 오류 발생: " + e.getMessage());
        }

        // 데이터 읽기 (DataInputStream)
        try (DataInputStream dis = new DataInputStream(new FileInputStream(inputFile))) {
            int intValue = dis.readInt();          // 정수 읽기
            double doubleValue = dis.readDouble(); // 실수 읽기
            String stringValue = dis.readUTF();    // 문자열 읽기

            System.out.println("파일에서 읽은 데이터:");
            System.out.println("정수: " + intValue);
            System.out.println("실수: " + doubleValue);
            System.out.println("문자열: " + stringValue);
        } catch (IOException e) {
            System.err.println("데이터 읽기 중 오류 발생: " + e.getMessage());
        }
    }
}

*/
