package week14_java2;
import java.io.*;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.util.Scanner;

public class ex03{
	   public static void main(String[] args) throws Exception{
		      Reader reader = new FileReader("./txt/source.txt");
		      BufferedReader br = new BufferedReader(reader);
		      
		      String name;
		      int age;
		      String adult;
		      
		      while(true) {
		         String data = br.readLine();
		         if (data == null) { 
		                break;
		            }
		         String[] data2 = data.split(" ");
		         name = data2[0];
		           age = Integer.parseInt(data2[1]);
		           adult = (age >= 18) ? "성년" : "미성년";
		            System.out.printf("[%s]님의 나이는 [%d]세로 [%s]입니다.%n", name, age, adult);
		      }
		      
		      br.close();
		   }
   

}


