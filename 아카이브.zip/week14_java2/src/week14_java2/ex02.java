package week14_java2;

import java.io.FileWriter;
import java.io.*;
import java.util.Scanner;

public class ex02 {
	public static void main(String[] args) throws Exception{
	      Scanner sc = new Scanner(System.in);
	      int num;
	      
	      System.out.print("입력할 학생 수 : ");
	      num = sc.nextInt();
	      sc.nextLine();
	      
	      String[] student = new String[num];
	      
	      for(int i = 0; i < student.length; i++ ) {
	         System.out.print("학생이름과 나이[i];");
	         student[i] = sc.nextLine();
	      }
	      
	      sc.close();
	      
	      Writer wr = new FileWriter("./txt/source.txt");
	      for (int i = 0; i < student.length; i++ ) {
	         wr.write(student[i] + "\n");
	      }
	      
	      wr.flush();
	      wr.close();
	   }

}
