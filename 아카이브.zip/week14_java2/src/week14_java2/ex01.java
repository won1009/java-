package week14_java2;

public class ex01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//바이트 입출력 스트림과 문자 입출력 스트림의 차이와 공통점을 조사하여 표로 간단하게 정리하세요 
	}

}
