package week14_java2;

import java.io.*;

public class ex04 {
    public static void main(String[] args) {
        try {
            Reader reader = new FileReader("txt/source.txt");
            BufferedReader br = new BufferedReader(reader);
            
            FileWriter writer = new FileWriter("chaewon.txt");
            BufferedWriter bw = new BufferedWriter(writer);

            String name;
            int age;
            String adult;
            
            while(true) {
                String data = br.readLine();
                if (data == null) { 
                    break;
                }
                String[] data2 = data.split(" ");
                name = data2[0];
                age = Integer.parseInt(data2[1]);
                adult = (age >= 18) ? "성년" : "미성년";
                String output = String.format("[%s]님의 나이는 [%d]세로 [%s]입니다.%n", name, age, adult);
                System.out.print(output); // 콘솔에 출력
                
                bw.write(output); // 파일에 출력
            }
            
            br.close();
            bw.close();
        } catch (IOException e) {
            System.out.println("파일 처리 중 오류가 발생했습니다: " + e.getMessage());
        }
    }
}
