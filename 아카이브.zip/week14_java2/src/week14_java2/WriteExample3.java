package week14_java2;
import java.io.OutputStream;
import java.io.FileOutputStream;

public class WriteExample3 {

	public static void main(String[] args) throws Exception {
		OutputStream os = new FileOutputStream("/Users/won/Desktop/Temp/test3.db");
		
		byte[] array = { 10, 20, 30, 40, 50 };
		
		os.write(array, 1, 3);
		
		os.flush();
		os.close();
	}

}