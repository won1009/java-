//이름과 배열의 개수를 입력 받아 아래 입출력형식과 같이 출력되도록 문제를 분석한 후 인터페이스가 적용된 객체적 프로그램 구조로 프로그램 하세요. (합격여부의 기준은 80점 이상)
package pk05;
public class Ex1 {
    public static void main(String[] args) {
       
        String name = "홍길동";
        int score1 = 100;
        int score2 = 97;
        double sum; // sum을 double로 정의
        double avg;
        char grade;
        
        sum = score1 + score2; // sum은 double로 계산
        System.out.print("이름과 배열의 개수를 입력하세요 :  ");
        System.out.print("[0]:");
       
      
        avg = sum / 2.0; // 평균은 double 형으로 계산

        // 학점 계산
        if (avg >= 90 && avg <= 100) {  grade = 'A';
        } else if (avg >= 80 && avg < 90) {    grade = 'B';
        } else if (avg >= 70 && avg < 80) {    grade = 'C';
        } else if (avg >= 60 && avg < 70) {    grade = 'D';
        } else { grade = 'F';
        }
        
        System.out.printf("입력된 이름과 두 개의 점수는 %s, %d, %d 이고,\n", name, score1, score2);
        System.out.printf("합은 %.2f, 평균은 %.2f, 학점은 %c 입니다.\n", sum, avg, grade);
    }
}
