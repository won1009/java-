package package2;

import java.util.Scanner;

public class SumOfDigits {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("숫자로 이루어진 문자열을 입력하세요: ");
            String input = scanner.nextLine().trim();

            if (input.isEmpty()) throw new IllegalArgumentException("다시 숫자 입력");

            int sum = 0;
            for (char ch : input.toCharArray()) {
                if (!Character.isDigit(ch)) throw new NumberFormatException("잘못된 입력, 다시 입력.");
                sum += ch - '0'; // 각 문자를 숫자로 변환하여 합계에 추가
            }

            System.out.println("입력된 숫자의 합은: " + sum);
        } catch (NumberFormatException e) {
            System.out.println(e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
