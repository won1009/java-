package package2;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Fibo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("피보나치 계산을 위한 양의 정수를 입력하세요: ");
            int N = scanner.nextInt();
            
            // 음수를 입력할 경우 예외를 발생시킴
            if (N < 0) {
                throw new IllegalArgumentException("피보나치 계산에는 음수를 입력할 수 없습니다.");
            }
            
            
            System.out.println("피보나치 수열의 " + N + "번째 항은: " + fibo(N));
        } catch (InputMismatchException e) {
            // 정수가 아닌 값을 입력했을 때 처리
            System.out.println("잘못된 입력입니다! 정수를 입력해 주세요.");
        } catch (IllegalArgumentException e) {
            // 음수를 입력했을 때 처리
            System.out.println(e.getMessage());
        } finally {
            scanner.close();
        }
    }

    static int fibo(int N) {
        if (N <= 1) { // N이 0 또는 1일 때 N을 반환
            return N;
        }
        return fibo(N - 2) + fibo(N - 1); // 피보나치 계산
    }
}
