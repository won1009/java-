package package2;


class Divisor {
    private int number;

    public Divisor(int number) {
        this.number = number;
    }

    public boolean isMultipleOfBoth() {
        return number % 5 == 0 && number % 7 == 0;
    }

    @Override
    public String toString() {
        return Integer.toString(number);
    }
}

public class AppEx01_2 {
    public static void main(String[] args) {
        int count = 0;
        
        System.out.println("1부터 100까지 중 5의 배수와 7의 배수 : ");

        for (int n = 1; n <= 100; n++) {
            Divisor divisor = new Divisor(n); // Divisor 객체 생성
            if (divisor.isMultipleOfBoth()) { // 5의 배수와 7의 배수인지 확인
                System.out.print(divisor + " ");
                count++;
            }
        }

        // 총 개수 출력
        System.out.println("\n갯수 " + count);
    }
}
