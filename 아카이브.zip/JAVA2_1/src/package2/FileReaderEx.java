package package2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileReaderEx {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("읽을 파일의 경로를 입력하세요: ");
	        String filePath = scanner.nextLine();

	        // 파일을 읽고 예외 처리하기
	        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
	            String line;
	            System.out.println("파일 내용:");
	            while ((line = reader.readLine()) != null) {
	                System.out.println(line);
	            }
	        } catch (FileNotFoundException e) {
	            System.out.println("파일을 찾을 수 없습니다: " + e.getMessage());
	        } catch (IOException e) {
	            System.out.println("파일을 읽는 중 오류가 발생했습니다: " + e.getMessage());
	        } finally {
	            scanner.close(); // Scanner 리소스 해제
	        }
	    }
	}
