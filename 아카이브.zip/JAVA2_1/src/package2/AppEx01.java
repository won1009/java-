//0911 2week

package package2;


public class AppEx01 {
    public static void main(String[] args) {

    	int count = 0; 
    	
        System.out.println("1부터 100까지 중 5의 배수와 7의 배수 : ");

        for (int n = 1; n <= 100; n++) {
            if (n % 5 == 0 && n % 7 == 0) {  
                System.out.print(n + " ");
                count++;
            }
        }

        
        System.out.println("\n갯수 " + count);
    }
}

