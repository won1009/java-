package package3;
import java.util.Scanner;

interface StudentInfo {
    void Score(); // 총점 및 평균 계산 메서드
    void Result();  // 결과 출력 메서드
}

class Student implements StudentInfo {
    String name;
    int[] scores;
    double sum;
    double avg;
    String grade;

    void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("이름과 배열의 갯수를 입력하시오 : ");
        name = scanner.next();
        int size = scanner.nextInt();
        scores = new int[size];

        for (int i = 0; i < size; i++) {
            System.out.print("["+i+"]:");
            scores[i] = scanner.nextInt();
        }
        scanner.close();
    }

    @Override
    public void Score() {
        sum = 0;
        for (int score : scores) {
            sum += score;
        }
        avg = sum / scores.length;

        if (avg >= 80) grade = "합격";
        else grade = "불합격";
    }

    @Override
    public void Result() {
        System.out.printf("[%s]님의 점수는 ", name);
        for (int i = 0; i < scores.length; i++) {
            System.out.printf("%d", scores[i]);
            if (i < scores.length - 1) System.out.print(", ");
        }
        System.out.printf("이고,\n총점은 %.2f, 평균은 %.2f으로 [%s]하셨습니다.\n", sum, avg, grade);
    }
}

public class Ex04 {
    public static void main(String[] args) {
        Student student = new Student();
        student.input();
        student.Score();
        student.Result();
    }
}
