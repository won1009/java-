//[문제3] 키보드로 500개의 실수형 점수를 입력 받아 총합과 학점이 출력되도록 객체적 프로그래밍 구조로 프로그램 하세요. 
//학점의 기준은 10점 단위의 ABCDF입니다. 
package package3;

import java.util.Scanner;
public class Ex3 {
    double sum;
    char hak;
    double arr[];
    
    public void process() {
    	double avg;
        arr = new double[500];
        Scanner sc = new Scanner(System.in);
        System.out.print("점수를 입력하세요 : ");
        for(int i = 0; i < arr.length; i++) {
            arr[i] = sc.nextDouble();
            sum += arr[i];
        }
        avg = sum / arr.length;
        
        if (avg >= 90) hak = 'A';
        else if (avg >= 80) hak = 'B';
        else if (avg >= 70) hak = 'C';
        else if (avg >= 60) hak = 'D';
        else hak = 'F';
            
        System.out.printf("총합 점수는 %.2f,학점은 %c입니다." ,sum,hak);
    }
    
    public static void main(String[] args) {
        Ex3 ex = new Ex3();
        ex.process();
    }
}
