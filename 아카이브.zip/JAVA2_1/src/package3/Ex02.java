//1030 9week
package package3;
import java.util.Scanner;

public class Ex02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("숫자를 입력하세요 : ");
        int score = scanner.nextInt();  // 사용자로부터 숫자 입력받기     
        scanner.close();
        
        String result;
       
        if (score >= 45 && score <= 75) {
            result = "통과";
        } else if ((score >= 30 && score <= 44) || (score >= 76 && score <= 90)) {
            result = "보류";
        } else {
            result = "불발";
        }
   
        System.out.printf("입력하신 숫자는 [%d]포인트로 [%s] 범위 안에 있습니다.\n", score, result);       
    }
}

// TODO Auto-generated method stub

		//키보드로 숫자를 입력 받아 해당 숫자가 45 ~ 75 사이면 통과 ,
		//30 ~44, 76~90 사이면 보류 , 그외에는 불발이라고 출력되도록 프로그램 하세요

		