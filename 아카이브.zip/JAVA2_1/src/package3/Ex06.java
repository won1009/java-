package package3;

import java.util.Scanner;
public class Ex06 {
   public static void main(String[] args) {
      double[] arrData; int n;
      double[] arrData_s1, arrData_s2;

      Scanner user = new Scanner(System.in);

      while(true) {
         arrData = new double[] {90, 78.5, 100, 56.9, 70, 56.3, 80, 50.5}; n=0;

         System.out.println("1) 오름차순으로 정렬하여 출력");
         System.out.println("2) 내림차순으로 정렬하여 출력");
         System.out.println("3) 원본출력");
         System.out.println("4) 프로그램 종료");
         System.out.print("번호를 선택하세요. : ");

         n = user.nextInt();

         if (n==1){ // 오름차순
            for(int i=0; i<arrData.length-1; i++) {
               for(int j=i; j<arrData.length; j++) {
                  if(arrData[i]>arrData[j]) {
                     double tmp;

                     tmp = arrData[i];
                     arrData[i] = arrData[j];
                     arrData[j] = tmp;
                  }}}
            arrData_s1 = arrData;
            System.out.print("[오름차순 정렬] : ");

            for(double data:arrData_s1) {//출력
               System.out.print(data+" ");
            }
            System.out.println();
         }
         else if (n==2) { //내림차순
            for(int i=0; i<arrData.length-1; i++) {
               for(int j=i; j<arrData.length; j++) {
                  if(arrData[i]<arrData[j]) {
                     double tmp;

                     tmp = arrData[i];
                     arrData[i] = arrData[j];
                     arrData[j] = tmp;
                  }}}
            
            arrData_s2 = arrData;
            System.out.print("[내림차순 정렬] : ");

            for(double data:arrData_s2) {//출력
               System.out.print(data+" ");
            }
            System.out.println();
         }
         else if(n==3) {
            System.out.print("[원본] : ");

            for(double data:arrData) {//출력
               System.out.print(data+" ");
            }
            System.out.println();
         }
         else 
            break;
         System.out.println();
      }
   user.close();
   }
}