package package13;


public class Ex02<T, U> {
    private T data;
    private U ename;

    
    public U getEname() {return ename;}
    public void setEname(U ename) { this.ename = ename;}
    


    public T getData() {return data;  }
    public void setData(T data) {this.data = data;}
    
    
    public void eprint() {
        System.out.println("data = " + data + ", ename = " + ename);
    }

    public static void main(String[] args) {
        Ex02<Integer, String> k = new Ex02<Integer, String>();
        
        k.setData(10);
        k.setEname("홍길동");
        k.eprint();  
        
        
        Ex02<Double, String> k2 = new Ex02<Double, String>();
        
        k2.setData(50.7);
        k2.setEname("홍길동");
        k2.eprint();  
    }
}


