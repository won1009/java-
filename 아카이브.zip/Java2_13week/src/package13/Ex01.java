//11/27
package package13;

public class Ex01<T> {
    private T data;  	// 데이터를 설정하는 메서드
    
    public T setData(T data) {
        this.data = data;
        return data;
    }
    public T getData() {	 // 데이터를 반환하는 메서드
        return data;
    }

    public void eprint() {	        // 데이터를 출력하는 메서드
        System.out.println("data = " + data);
    }

    public static void main(String[] args) {
        // Integer 타입의 Ex001 객체 생성 및 사용
        Ex01<Integer> k1 = new Ex01<>();
        Ex01<Double> k2 = new Ex01<>();
        Ex01<String> k3 = new Ex01<>();
        
        k1.setData(10);
        k2.setData(50.7);
        k3.setData("홍길동");
    
       
       
        k1.eprint();
        k2.eprint();
        k3.eprint();
    }
}
