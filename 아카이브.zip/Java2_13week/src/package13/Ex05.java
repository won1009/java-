package package13;

import static java. lang.System.out;

public class Ex05<T> {
   T [] v;
    
    public void set(T[] n) {
       v = n;
    }

    // 데이터 출력
    public void print() {
       for ( T s:v)
    	   out.println(s);
    }


    public static void main(String[] args) {
        // String 타입을 사용하는 Ex05 객체
        Ex05<String> k = new Ex05<>();
        String[] str = {"반가워", "여러분", "파이팅"};
        k.set(str);
        k.print(); // 반가워 여러분 파이 출력

        // Integer 타입을 사용하는 Ex05 객체
        Ex05<Integer> k2 = new Ex05<>();
        Integer[] num = {10, 20, 30};
        k2.set(num);
        k2.print(); // 10 20 30 출력
    }
}
