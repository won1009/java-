package package13;

interface InterBase<T> {
    public void setSize(int c);
    public void set(T a);
    public T get(int i);
}

class Data<T> implements InterBase<T> {
    private Object[] dataList;
    private int cnt = 0;

    // 배열 크기를 설정하는 메서드
    public void setSize(int c) {
        dataList = new Object[c];
    }

    // 배열 크기를 반환하는 메서드
    public int eLength() {
        return dataList.length;
    }

    // 데이터를 배열에 추가하는 메서드
    public void set(T a) {
            dataList[cnt++] = a;
    
    }

    // 특정 위치의 데이터를 반환하는 메서드
    public T get(int i) {  
            return (T) dataList[i];
    }

    // 데이터를 출력하는 메서드
    public void print() {
        for (int i = 0; i < cnt; i++) {
            System.out.print(dataList[i] + " ");
        }
        System.out.println();
    }
}

public class Ex04 {
    public static void main(String[] args) {
        // Integer 타입을 사용하는 Data 객체 생성 및 사용
        Data<Integer> k = new Data<>();
        k.setSize(5);

        for (int i = 1; i <= k.eLength(); i++) { // 배열 크기만큼 값 설정
            k.set(i * 10);
        }

        for (int i = 0; i < k.eLength(); i++) { // 배열 값 출력
            System.out.print(k.get(i) + " ");
        }
        System.out.println("\n---------------------");

        // String 타입을 사용하는 Data 객체 생성 및 사용
        Data<String> k2 = new Data<>();
        k2.setSize(3);

        k2.set("홍길동");
        k2.set("박달문");
        k2.set("이순길");

        k2.print(); // 홍길동 박달문 이순길 출력
    }
}
