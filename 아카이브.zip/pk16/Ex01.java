//package pk16;

import java.util.ArrayList;


class Point {
 private int x;  // x좌표
 private int y;  // y좌표

 public Point(int x, int y) {
     this.x = x;
     this.y = y;
 }

 // x 좌표 반환
 public int getX() {
     return x;
 }

 public int getY() {
     return y;
 }

 // x 좌표 설정
 public void setX(int x) {
     this.x = x;
 }

 public void setY(int y) {
     this.y = y;
 }

 // toString() 메서드 오버라이드
 @Override
 public String toString() {
     return "(" + x + "," + y + ")";
 }
}

//ArrayListTest 클래스
public class ArrayListTest {
 public static void main(String[] args) {
     // Point 객체를 저장할 ArrayList 생성
     ArrayList<Point> list = new ArrayList<>();

     // Point 객체 추가
     list.add(new Point(0, 0));
     list.add(new Point(4, 0));
     list.add(new Point(3, 5));
     list.add(new Point(-1, 3));

     // ArrayList 내용 출력
     System.out.println(list);
 }
}
