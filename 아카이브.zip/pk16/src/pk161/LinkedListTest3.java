//객체적 구조로 작성
package pk161;

import java.util.LinkedList;
import java.util.Scanner;

class NameManager {
	private LinkedList<String> list;
	
     public NameManager(){
         list = new LinkedList<String>(); //생성
     }
    public void a() {	    // 이름 입력 메서드
        Scanner in = new Scanner(System.in);
        for (int i = 1; i <= 3; i++) {
            System.out.print(i + "번째 이름: ");
            list.add(in.next()); 
        }
        in.close();
    }

        public void b() {	// 이름 출력 메서드
        System.out.print("입력된 이름: ");
        for (int i = 0; i<list.size(); i++) {
            System.out.print(list.get(i)+ " ");
        }
        System.out.println("입니다");
    }
}

// 3. Main 클래스: 프로그램 실행
public class LinkedListTest3 {
    public static void main(String[] args) {
        NameManager manager = new NameManager(); // NameManager 객체 생성
        
        manager.a();   // 이름 입력
        manager.b(); // 이름 출력
    }
}
