package pk161;

import java.util.Arrays;
import java.util.Collections;

class SortManager {
    Integer[] arr; // 배열 선언만
        public void setArray(Integer[] arr) {// 배열 초기화
        this.arr = arr;
    }

       public void a() {
        int tp;
        for (int i = 0; i < arr.length - 1; i++) {
            for (int a = i + 1; a < arr.length; a++) {
                if (arr[i] > arr[a]) {
                    tp = arr[i];
                    arr[i] = arr[a];
                    arr[a] = tp;
                }
            }
        }
        System.out.print("1. 직접 구현하여 오름차순으로 정렬된 결과: ");
        displayArray();
    }

    // Arrays.sort()를 사용한 오름차순 정렬
    public void b() {
        Arrays.sort(arr);
        System.out.print("2. Arrays.sort를 사용하여 오름차순으로 정렬된 결과: ");
        displayArray();
    }

    // Arrays.sort() + Collections.reverseOrder()를 사용한 내림차순 정렬
    public void c() {
        Arrays.sort(arr, Collections.reverseOrder());
        System.out.print("3. Arrays.sort를 사용하여 내림차순으로 정렬된 결과: ");
        displayArray();
    }

    // 배열 출력
    public void displayArray() {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

public class ArraySortTest2 {
    public static void main(String[] args) {
        SortManager manager = new SortManager();
        
        // 배열 초기화
        Integer[] arr = {10, 30, 25, 5, 20, -1, 7};
        manager.setArray(arr);

        // 정렬 및 결과 출력
        manager.a(); // 직접 구현한 오름차순 정렬
        manager.b();       // Arrays.sort()를 사용한 오름차순 정렬
        manager.c();      // Arrays.sort() + Collections.reverseOrder()를 사용한 내림차순 정렬
    }
}
