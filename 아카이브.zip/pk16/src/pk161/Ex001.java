package pk161;

import java.util.ArrayList;


class Point {
 private int x,y;  

 public Point(int x, int y) {
     this.x = x;
     this.y = y;
 }

 @Override
 public String toString() {
     return "(" + x + "," + y + ")";
 }
} //여기 외우기 

//ArrayListTest 클래스
public class Ex001 {
 public static void main(String[] args) {
     // Point 객체를 저장할 ArrayList 생성
     ArrayList<Point> list = new ArrayList<>();

     list.add(new Point(0, 0));
     list.add(new Point(4, 0));
     list.add(new Point(3, 5));
     list.add(new Point(-1, 3));
     System.out.println(list);
 }
}
