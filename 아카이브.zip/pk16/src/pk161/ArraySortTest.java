package pk161;

import java.util.Arrays;
import java.util.Collections;


public class ArraySortTest {
    public static void main(String[] args) {
        // 배열 선언 및 초기화
        Integer[] arr = {10, 30, 25, 5, 20, -1, 7};

        int tp;
        for (int i = 0; i < arr.length - 1; i++) {
            for (int a = i + 1; a < arr.length; a++) {
                if (arr[i] > arr[a]) {
                    tp = arr[i];
                    arr[i] = arr[a];
                    arr[a] = tp;
                }
            }
        }
        System.out.print("1. 직접 구현하여 오름차순으로 정렬된 결과: ");
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
        arr = new Integer[]{10, 30, 25, 5, 20, -1, 7}; // 원본 배열 재생성


        // Arrays.sort()를 사용한 오름차순 정렬
        Arrays.sort(arr);
        System.out.print("2. Arrays.sort를 사용하여 오름차순으로 정렬된 결과: ");
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();

        arr = new Integer[]{10, 30, 25, 5, 20, -1, 7};

        // Arrays.sort() + Collections.reverseOrder()를 사용한 내림차순 정렬
        Arrays.sort(arr, Collections.reverseOrder());
        System.out.print("3. Arrays.sort를 사용하여 내림차순으로 정렬된 결과: ");
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
