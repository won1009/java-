//키보드로 3명의 이름을 입력받아 입출력형식을 맞춰 작성(절차적 구) 


package pk161;

import java.util.LinkedList;
import java.util.Scanner;

public class LinkListTest {
    public static void main(String[] args) {
        // 이름을 저장할 LinkedList 생성
        LinkedList<String> list = new LinkedList<>();

        // 1. 이름 입력
        Scanner in = new Scanner(System.in);
        for (int i = 1; i <= 3; i++) {
            System.out.print(i + "번째 이름: ");
            list.add(in.next());
        }
        in.close();

        // 2. 이름 출력
        System.out.print("입력된 이름: ");
        for (int i = 0; i < list.size(); i++) {
            System.out.print(list.get(i) + " ");
        }
        System.out.println("입니다");
    }
}

/*
 * package pk16;


import java.util.LinkedList;
import java.util.Scanner;

public class LinkListTest {
	public static void main(String args[]) {
		 LinkedList<String> list = new LinkedList<>();		
	
		
		Scanner in = new Scanner(System.in);
		
		
		System.out.print("1번째 이름 : ");
		String name1 = in.nextLine();
		System.out.print("2번째 이름 : ");
		String name2 = in.nextLine();

		System.out.print("3번째 이름 : ");
		String name3 = in.nextLine();

		list.add(name1);
		list.add(name2);
		list.add(name3);
		
		System.out.print("입력된 이름 : "  + list + "입니다.");
		
	}
}
 */