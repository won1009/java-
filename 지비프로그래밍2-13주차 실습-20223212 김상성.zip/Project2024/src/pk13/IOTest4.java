package pk13;

import java.io.*;
public class IOTest4 {

	public static void main(String[] args) throws Exception {
		FileOutputStream fos = new FileOutputStream("./file_data/soc.db");
		DataOutputStream dos = new DataOutputStream(fos);
		
		dos.writeUTF("홍길동");
		dos.writeDouble(95.5);
		dos.writeInt(1);
		
		dos.writeUTF("김자바");
		dos.writeDouble(80.3);
		dos.writeInt(2);
		
		dos.flush(); 	dos.close();	fos.close();
		
		FileInputStream fis = new FileInputStream("./file_data/soc.db");
		DataInputStream dis = new DataInputStream(fis);
		
		for ( int i = 0; i < 2; i++) {
			String name = dis.readUTF();
			double score = dis.readDouble();
			int order = dis.readInt();
			System.out.println(name + " : " + score + " : " + order);
		}
		dis.close();	fos.close();
	}

}
